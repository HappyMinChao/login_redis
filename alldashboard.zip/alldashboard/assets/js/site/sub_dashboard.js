
		//console.log(window.location);
            $(function () {
    $(document).ready(function () {
        Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });

        $('#container').highcharts({
            chart: {
                type: 'spline',
                animation: Highcharts.svg, // don't animate in old IE
                marginRight: 10,
                events: {
                    load: function () {
						 var series = this.series[0];
						
                        setInterval(function () {
							$.ajax({   
							url: "app/sub_livechart", 
							async: false,
							dataType: "html", 
							success: function(y) {
								var x = (new Date()).getTime();
                            series.addPoint([x, parseInt(y)], true, true);
							
								//console.log(a);
							}
						});
                            
                        }, 7000);
                    }
                }
            },
            title: {
                text: ''
            },
            xAxis: {
                type: 'datetime',
                tickPixelInterval: 300
            },
            yAxis: {
                title: {
                    text: 'Value'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + '</b><br/>Time : ' +
                        Highcharts.dateFormat('%H:%M:%S', this.x) + '<br/>' +
                        'No.:'+Highcharts.numberFormat(this.y, 0)+'';
                }
            },
            legend: {
                enabled: false
            },
            exporting: {
                enabled: false
            },
            series: [{
                name: 'Active Attendance',
                data: (function () {
                    // generate an array of random data
                    var data = [],
                        time = (new Date()).getTime(),
                        i;

                    for (i = -19; i <= 0; i += 1) {
						data.push({
                            x: time + i * 1000,
                            y: parseInt($('#count_present').html())
                        });
                    }
                    return data;
                }())
            }]
        });

	loadbar();	
	setInterval(function () {loadbar();}, 300000);				
	function loadbar(){							
			$.ajax({
							url: "app/sub_employeechart", 
							async: false,
							dataType: "html", 
							success: function(result) {
								//console.log(result);
							var obj = JSON.parse(result);
							animate_count('total_emp',$('#total_emp').html(),parseInt(obj.tot_emp));
							animate_count('count_reg',$('#count_reg').html(),parseInt(obj.tot_reg));
							animate_count('count_present',$('#count_present').html(),parseInt(obj.t_in-obj.t_out));
							animate_count('count_subdevice',$('#count_subdevice').html(),parseInt(obj.t_device_active));
								
								
							
   $('#employeechart').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            categories: [
                'Employees'
            ]
        },
        yAxis: {
            min: 0,
            title: {
                text: 'No. of Employees'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: .2,
                borderWidth: 0
            }
        },
		
        series: [	
		
		 {
            name: 'Total Employee',
            data: [parseInt(obj.tot_emp)],
			color: '#060'

        }, {
            name: 'Registered Employee',
            data: [parseInt(obj.tot_reg)],
			color: '#003399'

        },{
            name: 'Aadhar Verified ',
            data: [parseInt(obj.tot_qcpass)],
			color: '#3C6'

        }, {
            name: 'Aadhar Rejected',
            data: [parseInt(obj.tot_qcfail)],
			color: '#F00'

        },{
            name: 'QC Pending',
            data: [parseInt(obj.tot_reg)-parseInt(obj.tot_qcpass)-parseInt(obj.tot_qcfail)],
			color: '#FF9933'

        }]
    });
	
	}
	})
	}					
loadlinebar();
	setInterval(function () {loadlinebar();}, 20000);					
	function loadlinebar(){							
			$.ajax({
							url: "app/sub_networkchart", 
							async: false,
							dataType: "html", 
							success: function(result) {
								//console.log(result);
							var data = JSON.parse(result);
								


    var series = [{
        name: 'Ethernet',
        data: []
    }, {
        name: 'Mobile',
        data: []
    }, {
        name: 'WiFi',
        data: []
    }],
        categories = [];
    
    
    for(var category in data) {
        var points = data[category];
        categories.push(category);
        for(var i in points) {
             series[i].data.push(points[i]);  
        }
    }

    var i = 1.0;
    $('#networkchart').highcharts({
        title: {
            text: ' ',
            x: -20 //center
        },
        subtitle: {
            text: ' ',
            x: -20
        },
        xAxis: {
            categories: categories
        },
        yAxis: {
            title: {
                text: 'Seconds'
            },
            plotLines: [{
                value: 0,
                width: 1,
                color: '#808080'
            }]
        },
        tooltip: {
            valueSuffix: 'sec'
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle',
            borderWidth: 0
        },
        series: series
    });
	
	}
	})
	}

});
});
 var options = {
        useEasing : true, // toggle easing
        useGrouping : true, // 1,000,000 vs 1000000
        separator : ',', // character to use as a separator
        decimal : '.', // character to use as a decimal
    }
    var useOnComplete = false;
    var useEasing = true;
    var useGrouping = true;

    var demo;

    // create instance
    function animate_count(id,start,end) {
        // fire animation
        // var element = document.querySelector('.jumbo');
        demo = new countUp(id, parseInt(start), parseInt(end), 0, 2.5, options);
		demo.start();

    }
