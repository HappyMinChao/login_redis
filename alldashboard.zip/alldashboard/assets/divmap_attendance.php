<?php
$db         = mysql_connect('localhost','root','xyz');
$mysql_conn = mysql_select_db('cippn', $db);

$today      = date('Y-m-d');
$creation_date      = date('Y-m-d H:i:s');
$dt         = date("Ymd");
$rows_inserted=0;

$dir="D:/xampp/htdocs/zap/divmap/";
if (is_dir($dir)) {
echo 'hi';
    if ($dh = opendir($dir)) {
        while (($file_name = readdir($dh)) !== false) {
		$err='';
		$parts = explode(".", $file_name);
		if($parts[1]=='txt' || $parts[1]=='TXT')
			{
			//$org_id = $parts[0];
			//echo "The file $file_name exists with orgid: $org_id and ";
			$file_with_path="D:/xampp/htdocs/zap/divmap/" . $file_name;
			$myfile = fopen($file_with_path, "r") or die("Unable to open file!");
			echo "LineCount: ".$lines = count(file($file_with_path)); 
			echo "<br/>";
			while(!feof($myfile)) {
			   $data = fgets($myfile);
			   $in_data = explode(",", $data);
			/*   $sel_div_qry=mysql_query("select count(*) as cnt from ms_org_dept where department='$div_name' and org_id='$org_id'");
			  $sel_div_data=mysql_fetch_assoc($sel_div_qry);
			  $cnt=$sel_div_data['cnt'];
				if (empty($div_name) || $cnt) continue;
				echo $div_name."--";
				$sel_qry=mysql_query("SELECT TRIM(LEADING '0' FROM org_dept_key) as maxsl FROM ms_org_dept order by sno desc limit 1");
				$sel_data=mysql_fetch_assoc($sel_qry);
				
			    $maxsl = str_pad(($sel_data['maxsl'] + 1), 6, '0', STR_PAD_LEFT); */
				
				$ins_qry= mysql_query("insert into geo_location(loc_type,contact_name,state,district,block,location,pincode,vle_email,std_code,vle_phone,vle_mobile,address)
				values('$in_data[0]','$in_data[1]','$in_data[2]','$in_data[3]','$in_data[4]','$in_data[5]','$in_data[6]','$in_data[7]','$in_data[8]','$in_data[9]','$in_data[10]','$in_data[11]')");
				if(!($ins_qry))
				{
				echo "In<br/>";
				$err=$err."Error while inserting</br>";
				}
				else
				{
				echo "Success<br/>";
				$rows_inserted=$rows_inserted+1;
				}
				
		//	Location Type	Vle Contact Name	State	District	Block	Location	Pincode	Vle_email	Std_code	Vle_phone	Vle_mobile	Address
	
			}
			fclose($myfile);

           	   
		   }
        
		}
        
    }
}
closedir($dh);

echo "Total rows inserted: $rows_inserted";




?>
