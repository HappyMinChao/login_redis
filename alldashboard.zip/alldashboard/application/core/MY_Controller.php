<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*  Author  : 	Abhishek Ranjan 
	e-Mail	:	abhishek349@gmail.com
	web		:	www.abhishekranjan.com
*/

class MY_Controller extends CI_Controller {


	function __construct()
	{
		parent::__construct();
		$this->ci =& get_instance();
		$this->load->helper(array('form', 'url'));
		$this->load->library('form_validation');
		//$this->ci->load->library('session');
		//$this->ci->lang->load('nehbr_auth');
		//$this->load->library('nehbr_auth');
		//$this->load->library('Nb_lib');
	}
	
}
// END Controller class

/* End of file MY_Controller.php */
/* Location: ./system/core/MY_Controller.php */