<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

class Alldashboard_model extends CI_Model {
 	function __construct() 
    {
        parent::__construct();
		$this->DB1 =	$this->load->database('vi',TRUE); // Attendance
                $this->DB2 =	$this->load->database('central',TRUE); // central
                $this->DB3 =	$this->load->database('hr',TRUE); // haryana
                $this->DB4 =	$this->load->database('chandigarh',TRUE); // chandigarh
                $this->DB5 =	$this->load->database('maharashtra',TRUE); // maharashtra
                $this->DB6 =	$this->load->database('bihar',TRUE); // Bihar
                $this->DB7 =	$this->load->database('goa',TRUE); // Goa
                $this->DB8 =	$this->load->database('punjab',TRUE); // Punjab
                $this->DB9 =	$this->load->database('mp',TRUE); // MP
                $this->DB10 =	$this->load->database('gujarat',TRUE); // Gujarat
                $this->DB11 =	$this->load->database('kerala',TRUE); // Kerala
                $this->DB12 =	$this->load->database('karnataka',TRUE); // Karnataka
                $this->DB13 =	$this->load->database('tamilnadu',TRUE); // Tamilnadu
                $this->DB14 =	$this->load->database('andhra',TRUE); // Andhra
                $this->DB15 =	$this->load->database('mizoram',TRUE); // Mizoram
                $this->DB16 =	$this->load->database('tripura',TRUE); // Tripura
                $this->DB17 =	$this->load->database('jharkhand',TRUE); // Jharkhand
                $this->DB18 =	$this->load->database('assam',TRUE); // Assam
                $this->DB19 =	$this->load->database('manipur',TRUE); // Manipur
                $this->DB20 =	$this->load->database('meghalaya',TRUE); // Meghalaya
                $this->DB21 =	$this->load->database('wb',TRUE); // West Bengal
                $this->DB22 =	$this->load->database('odisha',TRUE); // Odisha
                $this->DB23 =	$this->load->database('jk',TRUE); // Jammu & Kashmir
                $this->DB24 =	$this->load->database('himachal',TRUE); // Himachal
                $this->DB25 =	$this->load->database('up',TRUE); // Uttar Pradesh
                $this->DB26 =	$this->load->database('raj',TRUE); // Rajasthan
                $this->DB27 =	$this->load->database('arunachal',TRUE); // Arunachal Pradesh
                $this->DB28 =	$this->load->database('uk',TRUE); // Uttrakhand
                $this->DB29 =	$this->load->database('sikkim',TRUE); // Sikkim
                $this->DB30 =	$this->load->database('delhi',TRUE); // Delhi
                $this->DB31 =	$this->load->database('ut',TRUE); // UT
                $this->DB32 =	$this->load->database('chhattisgarh',TRUE); // Chhattisgarh
                $this->DB33 =	$this->load->database('nagaland',TRUE); // nagaland
                $this->DB34 =	$this->load->database('telangana',TRUE); // telangana
                
  }
	
	function count_present_employee($id)
	{
		if($id==1){
                    $this->DB1->where(array('org_id'=>'global'));
		    $this->DB1->select('t_in,t_reg');
		    $query=$this->DB1->get('dashboard_org')->result();
                  }
                  
                if($id==2){
                    $this->DB2->where(array('org_id'=>'global'));
		    $this->DB2->select('t_in,t_reg');
		    $query=$this->DB2->get('dashboard_org')->result();
                  }
                  if($id==3){
                    $this->DB3->where(array('org_id'=>'global'));
		    $this->DB3->select('t_in,t_reg');
		    $query=$this->DB3->get('dashboard_org')->result();
                  }
                  if($id==4){
                    $this->DB4->where(array('org_id'=>'global'));
		    $this->DB4->select('t_in,t_reg');
		    $query=$this->DB4->get('dashboard_org')->result();
                  }
                  if($id==5){
                    $this->DB5->where(array('org_id'=>'global'));
		    $this->DB5->select('t_in,t_reg');
		    $query=$this->DB5->get('dashboard_org')->result();
                  }
                  if($id==6){
                    $this->DB6->where(array('org_id'=>'global'));
		    $this->DB6->select('t_in,t_reg');
		    $query=$this->DB6->get('dashboard_org')->result();
                  }
                  if($id==7){
                    $this->DB7->where(array('org_id'=>'global'));
		    $this->DB7->select('t_in,t_reg');
		    $query=$this->DB7->get('dashboard_org')->result();
                  }
                  if($id==8){
                    $this->DB8->where(array('org_id'=>'global'));
		    $this->DB8->select('t_in,t_reg');
		    $query=$this->DB8->get('dashboard_org')->result();
                  }
                  if($id==9){
                    $this->DB9->where(array('org_id'=>'global'));
		    $this->DB9->select('t_in,t_reg');
		    $query=$this->DB9->get('dashboard_org')->result();
                  }
                  if($id==10){
                    $this->DB10->where(array('org_id'=>'global'));
		    $this->DB10->select('t_in,t_reg');
		    $query=$this->DB10->get('dashboard_org')->result();
                  }
                  if($id==11){
                    $this->DB11->where(array('org_id'=>'global'));
		    $this->DB11->select('t_in,t_reg');
		    $query=$this->DB2->get('dashboard_org')->result();
                  }
                  if($id==12){
                    $this->DB12->where(array('org_id'=>'global'));
		    $this->DB12->select('t_in,t_reg');
		    $query=$this->DB12->get('dashboard_org')->result();
                  }
                  if($id==13){
                    $this->DB13->where(array('org_id'=>'global'));
		    $this->DB13->select('t_in,t_reg');
		    $query=$this->DB13->get('dashboard_org')->result();
                  }
                  if($id==14){
                    $this->DB14->where(array('org_id'=>'global'));
		    $this->DB14->select('t_in,t_reg');
		    $query=$this->DB14->get('dashboard_org')->result();
                  }
                  if($id==15){
                    $this->DB15->where(array('org_id'=>'global'));
		    $this->DB15->select('t_in,t_reg');
		    $query=$this->DB15->get('dashboard_org')->result();
                  }
                  if($id==16){
                    $this->DB16->where(array('org_id'=>'global'));
		    $this->DB16->select('t_in,t_reg');
		    $query=$this->DB16->get('dashboard_org')->result();
                  }
                  if($id==17){
                    $this->DB17->where(array('org_id'=>'global'));
		    $this->DB17->select('t_in,t_reg');
		    $query=$this->DB17->get('dashboard_org')->result();
                  }
                  if($id==18){
                    $this->DB18->where(array('org_id'=>'global'));
		    $this->DB18->select('t_in,t_reg');
		    $query=$this->DB18->get('dashboard_org')->result();
                  }
                  if($id==19){
                    $this->DB19->where(array('org_id'=>'global'));
		    $this->DB19->select('t_in,t_reg');
		    $query=$this->DB19->get('dashboard_org')->result();
                  }
                  if($id==20){
                    $this->DB20->where(array('org_id'=>'global'));
		    $this->DB20->select('t_in,t_reg');
		    $query=$this->DB20->get('dashboard_org')->result();
                  }
                  if($id==21){
                    $this->DB21->where(array('org_id'=>'global'));
		    $this->DB21->select('t_in,t_reg');
		    $query=$this->DB21->get('dashboard_org')->result();
                  }
                  if($id==22){
                    $this->DB22->where(array('org_id'=>'global'));
		    $this->DB22->select('t_in,t_reg');
		    $query=$this->DB22->get('dashboard_org')->result();
                  }
                  if($id==23){
                    $this->DB23->where(array('org_id'=>'global'));
		    $this->DB23->select('t_in,t_reg');
		    $query=$this->DB23->get('dashboard_org')->result();
                  }
                  if($id==24){
                    $this->DB24->where(array('org_id'=>'global'));
		    $this->DB24->select('t_in,t_reg');
		    $query=$this->DB24->get('dashboard_org')->result();
                  }
                  if($id==25){
                    $this->DB25->where(array('org_id'=>'global'));
		    $this->DB25->select('t_in,t_reg');
		    $query=$this->DB25->get('dashboard_org')->result();
                  }
                  if($id==26){
                    $this->DB26->where(array('org_id'=>'global'));
		    $this->DB26->select('t_in,t_reg');
		    $query=$this->DB26->get('dashboard_org')->result();
                  }
                  if($id==27){
                    $this->DB27->where(array('org_id'=>'global'));
		    $this->DB27->select('t_in,t_reg');
		    $query=$this->DB27->get('dashboard_org')->result();
                  }
                  if($id==28){
                    $this->DB28->where(array('org_id'=>'global'));
		    $this->DB28->select('t_in,t_reg');
		    $query=$this->DB28->get('dashboard_org')->result();
                  }
                  if($id==29){
                    $this->DB29->where(array('org_id'=>'global'));
		    $this->DB29->select('t_in,t_reg');
		    $query=$this->DB29->get('dashboard_org')->result();
                  }
                  if($id==30){
                    $this->DB30->where(array('org_id'=>'global'));
		    $this->DB30->select('t_in,t_reg');
		    $query=$this->DB30->get('dashboard_org')->result();
                  }
                  if($id==31){
                    $this->DB31->where(array('org_id'=>'global'));
		    $this->DB31->select('t_in,t_reg');
		    $query=$this->DB31->get('dashboard_org')->result();
                  }
                  if($id==32){
                    $this->DB32->where(array('org_id'=>'global'));
		    $this->DB32->select('t_in,t_reg');
		    $query=$this->DB32->get('dashboard_org')->result();
                  }
                  if($id==33){
                    $this->DB33->where(array('org_id'=>'global'));
		    $this->DB33->select('t_in,t_reg');
		    $query=$this->DB33->get('dashboard_org')->result();
                  }
                  if($id==34){
                    $this->DB34->where(array('org_id'=>'global'));
		    $this->DB34->select('t_in,t_reg');
		    $query=$this->DB34->get('dashboard_org')->result();
                  }
                  
		return $query[0];
	}
        
        /****************functions for ajax*******************/
        function count_employeechart()
	{
            
                $this->DB1->where(array('org_id'=>'global'));
		$this->DB1->select('t_reg as tot_reg,t_in');
		$query=$this->DB1->get('dashboard_org')->result();
          
		return $query[0];
	}
      
        function count_employeechart2()
	{
                $this->DB2->where(array('org_id'=>'global'));
		$this->DB2->select('t_reg as tot_reg,t_in');
		$query=$this->DB2->get('dashboard_org')->result();
		
		return $query[0];
	}
        function count_employeechart3()
	{
                $this->DB3->where(array('org_id'=>'global'));
		$this->DB3->select('t_reg as tot_reg,t_in');
		$query=$this->DB3->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart4()
	{
                $this->DB4->where(array('org_id'=>'global'));
		$this->DB4->select('t_reg as tot_reg,t_in');
		$query=$this->DB4->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart5()
	{
                $this->DB5->where(array('org_id'=>'global'));
		$this->DB5->select('t_reg as tot_reg,t_in');
		$query=$this->DB5->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart6()
	{
                $this->DB6->where(array('org_id'=>'global'));
		$this->DB6->select('t_reg as tot_reg,t_in');
		$query=$this->DB6->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart7()
	{
                $this->DB7->where(array('org_id'=>'global'));
		$this->DB7->select('t_reg as tot_reg,t_in');
		$query=$this->DB7->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart8()
	{
                $this->DB8->where(array('org_id'=>'global'));
		$this->DB8->select('t_reg as tot_reg,t_in');
		$query=$this->DB8->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart9()
	{
                $this->DB9->where(array('org_id'=>'global'));
		$this->DB9->select('t_reg as tot_reg,t_in');
		$query=$this->DB9->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart10()
	{
                $this->DB10->where(array('org_id'=>'global'));
		$this->DB10->select('t_reg as tot_reg,t_in');
		$query=$this->DB10->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart11()
	{
                $this->DB11->where(array('org_id'=>'global'));
		$this->DB11->select('t_reg as tot_reg,t_in');
		$query=$this->DB11->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart12()
	{
                $this->DB12->where(array('org_id'=>'global'));
		$this->DB12->select('t_reg as tot_reg,t_in');
		$query=$this->DB12->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart13()
	{
                $this->DB13->where(array('org_id'=>'global'));
		$this->DB13->select('t_reg as tot_reg,t_in');
		$query=$this->DB13->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart14()
	{
                $this->DB14->where(array('org_id'=>'global'));
		$this->DB14->select('t_reg as tot_reg,t_in');
		$query=$this->DB14->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart15()
	{
                $this->DB15->where(array('org_id'=>'global'));
		$this->DB15->select('t_reg as tot_reg,t_in');
		$query=$this->DB15->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart16()
	{
                $this->DB16->where(array('org_id'=>'global'));
		$this->DB16->select('t_reg as tot_reg,t_in');
		$query=$this->DB16->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart17()
	{
                $this->DB17->where(array('org_id'=>'global'));
		$this->DB17->select('t_reg as tot_reg,t_in');
		$query=$this->DB17->get('dashboard_org')->result();
		
		return $query[0];
	}

        function count_employeechart18()
	{
                $this->DB18->where(array('org_id'=>'global'));
		$this->DB18->select('t_reg as tot_reg,t_in');
		$query=$this->DB18->get('dashboard_org')->result();
		
		return $query[0];
	}
  function count_employeechart19()
	{
                $this->DB19->where(array('org_id'=>'global'));
		$this->DB19->select('t_reg as tot_reg,t_in');
		$query=$this->DB19->get('dashboard_org')->result();
		
		return $query[0];
	}
	
          function count_employeechart20()
	{
                $this->DB20->where(array('org_id'=>'global'));
		$this->DB20->select('t_reg as tot_reg,t_in');
		$query=$this->DB20->get('dashboard_org')->result();
		
		return $query[0];
	}
        
          function count_employeechart21()
	{
                $this->DB21->where(array('org_id'=>'global'));
		$this->DB21->select('t_reg as tot_reg,t_in');
		$query=$this->DB21->get('dashboard_org')->result();
		
		return $query[0];
	}
         function count_employeechart22()
	{
                $this->DB22->where(array('org_id'=>'global'));
		$this->DB22->select('t_reg as tot_reg,t_in');
		$query=$this->DB22->get('dashboard_org')->result();
		
		return $query[0];
	}
          function count_employeechart23()
	{
                $this->DB23->where(array('org_id'=>'global'));
		$this->DB23->select('t_reg as tot_reg,t_in');
		$query=$this->DB23->get('dashboard_org')->result();
		
		return $query[0];
	}
        
          function count_employeechart24()
	{
                $this->DB24->where(array('org_id'=>'global'));
		$this->DB24->select('t_reg as tot_reg,t_in');
		$query=$this->DB24->get('dashboard_org')->result();
		
		return $query[0];
	}
          function count_employeechart25()
	{
                $this->DB25->where(array('org_id'=>'global'));
		$this->DB25->select('t_reg as tot_reg,t_in');
		$query=$this->DB25->get('dashboard_org')->result();
		
		return $query[0];
	}
        
          function count_employeechart26()
	{
                $this->DB26->where(array('org_id'=>'global'));
		$this->DB26->select('t_reg as tot_reg,t_in');
		$query=$this->DB26->get('dashboard_org')->result();
		
		return $query[0];
	}
        
          function count_employeechart27()
	{
                $this->DB27->where(array('org_id'=>'global'));
		$this->DB27->select('t_reg as tot_reg,t_in');
		$query=$this->DB27->get('dashboard_org')->result();
		
		return $query[0];
	}
          function count_employeechart28()
	{
                $this->DB28->where(array('org_id'=>'global'));
		$this->DB28->select('t_reg as tot_reg,t_in');
		$query=$this->DB28->get('dashboard_org')->result();
		
		return $query[0];
	}
          function count_employeechart29()
	{
                $this->DB29->where(array('org_id'=>'global'));
		$this->DB29->select('t_reg as tot_reg,t_in');
		$query=$this->DB29->get('dashboard_org')->result();
		
		return $query[0];
	}
          function count_employeechart30()
	{
                $this->DB30->where(array('org_id'=>'global'));
		$this->DB30->select('t_reg as tot_reg,t_in');
		$query=$this->DB30->get('dashboard_org')->result();
		
		return $query[0];
	}
        
          function count_employeechart31()
	{
                $this->DB31->where(array('org_id'=>'global'));
		$this->DB31->select('t_reg as tot_reg,t_in');
		$query=$this->DB31->get('dashboard_org')->result();
		
		return $query[0];
	}
         function count_employeechart32()
	{
                $this->DB32->where(array('org_id'=>'global'));
		$this->DB32->select('t_reg as tot_reg,t_in');
		$query=$this->DB32->get('dashboard_org')->result();
		
		return $query[0];
	} 
          function count_employeechart33()
	{
                $this->DB33->where(array('org_id'=>'global'));
		$this->DB33->select('t_reg as tot_reg,t_in');
		$query=$this->DB33->get('dashboard_org')->result();
		
		return $query[0];
	}
          function count_employeechart34()
	{
                $this->DB34->where(array('org_id'=>'global'));
		$this->DB34->select('t_reg as tot_reg,t_in');
		$query=$this->DB34->get('dashboard_org')->result();
		
		return $query[0];
	}
        
        
}

/* End of file app_model.php */
/* Location: ./application/modules/app/models/app_model.php */