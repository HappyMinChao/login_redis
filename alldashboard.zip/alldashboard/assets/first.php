<?php
echo "first php";

?>