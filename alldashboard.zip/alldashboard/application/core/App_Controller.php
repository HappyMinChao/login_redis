<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*  Author  : 	Abhishek Ranjan 
	e-Mail	:	abhishek349@gmail.com
	web		:	www.abhishekranjan.com
*/

class App_Controller extends MY_Controller {

	function __construct()
	{
		parent::__construct();
		if (!$this->nehbr_auth->is_logged_in()) 
		{							
			$this->nb_lib->no_cache();		// logged in
			redirect('/auth/login/', 'refresh');
		} 
		
	}
}
// END Controller class

/* End of file Controller.php */
/* Location: ./system/core/App_Controller.php */