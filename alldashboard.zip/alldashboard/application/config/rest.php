<?php defined('BASEPATH') OR exit('No direct script access allowed');


$config['force_https'] = FALSE;

/*
|--------------------------------------------------------------------------
| AUA URL
|--------------------------------------------------------------------------
|
| The url of AUA/ASA service
|
|	JH AUA  = 'http://117.239.23.169/aua/auaservice/authenticate';
|	NIC AUA = 'http://10.249.34.250:8080/NicASAServer/ASAMain/1.6';
|
*/
$config['aua_url'] = 'http://117.239.23.169/aua/auaservice/authenticate';
$config['rest_default_format'] = 'xml';
$config['rest_status_field_name'] = 'status';
$config['rest_message_field_name'] = 'error';
$config['enable_emulate_request'] = TRUE;
$config['rest_realm'] = 'Attendance API';
$config['rest_auth'] = 'basic';
$config['auth_source'] = '';
$config['auth_library_class'] = '';
$config['auth_library_function'] = '';
$config['rest_valid_logins'] = array('Rest_ser-Usr_id' => 'P~h+4_6!%v^S');
$config['rest_ip_whitelist_enabled'] = false;
$config['rest_ip_whitelist'] = '';
$config['rest_ip_blacklist_enabled'] = false;
$config['rest_ip_blacklist'] = '';
$config['rest_database_group'] = 'default';
$config['rest_keys_table'] = 'keys';
$config['rest_enable_keys'] = FALSE;
$config['rest_key_column'] = 'key';
$config['rest_key_length'] = 40;
$config['rest_key_name'] = 'X-API-KEY';
$config['rest_logs_table'] = 'logs';
$config['rest_enable_logging'] = FALSE;
$config['rest_access_table'] = 'access';
$config['rest_enable_access'] = FALSE;
$config['rest_logs_json_params'] = FALSE;
$config['rest_limits_table'] = 'limits';
$config['rest_enable_limits'] = FALSE;
$config['rest_ignore_http_accept'] = FALSE;
$config['rest_ajax_only'] = FALSE;

/* End of file config.php */
/* Location: ./system/application/config/rest.php */
