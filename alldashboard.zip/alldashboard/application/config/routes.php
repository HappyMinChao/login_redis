<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
*/

$route['default_controller'] = "alldashboard";

$route['checkstatus'] = "alldashboard/CheckStatus";

$route['404_override'] = 'alldashboard';
$route['api/(:any)'] = "api/$1";






/* End of file routes.php */
/* Location: ./application/config/routes.php */