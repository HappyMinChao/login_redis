<?php
# FileName="connect.php"
$hostname = "localhost";
$database = "attendance_app";
$username = "root";
$password = "xyz";

//connect to mysql server
//$mysqli = new mysqli($host, $username, $password, $db_name);
 $mysqli = new mysqli($hostname , $username , $password, $database );

//check if any connection error was encountered
if(mysqli_connect_errno()) {
    echo "Error: Could not connect to database.";
    exit;
}
?>