<aside class="right-side" style="margin-left: 0px;"> 
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> All Dashboards <small> Biometric Attendance System</small> </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url();?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    </ol>
  </section>
  
  <!-- Main content -->
  <section class="content"> 
    
    <!-- Small boxes (Stat box) top statistics shorts -->
    <div class="row">
      
     <!--1st row start-->
      <!-- ./col attendance start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Attendance.gov.in</h2></div>
            <div class="alldashdetail">
            <div class="inner">
           
                <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://attendance.gov.in/" height="70" frameborder="0"></iframe> 
                
          </div>
            
                </div>    
          
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col attendance end -->
       <!-- ./col central Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Central.attendance</h2></div>
            <div class="alldashdetail">
            <div class="inner">
          <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://central.attendance.gov.in/" height="70" frameborder="0"></iframe> 
       
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://central.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col central end-->
       <!-- ./col haryana start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Haryana</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://haryana.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://haryana.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col haryana end -->
      
       <!-- ./col chandigarh start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Chandigarh</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://chandigarh.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div> 
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://chandigarh.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col chandigarh end -->
       <!--1st row end-->
       
        <!--2nd row start-->
       <!-- ./col maharashtra start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Maharashtra</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://maharashtra.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://maharashtra.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col maharashtra end -->
      
       <!-- ./col bihar start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Bihar</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://bihar.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://bihar.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col bihar end-->
      
      <!-- ./col goa start-->
     <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Goa</h2></div>
          <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://goa.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>  
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://goa.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col -->
      
      <!-- ./col punjab start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Punjab</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://punjab.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://punjab.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      
       <!--2nd row end-->
      
      <!--3rd row start-->
      
      <!-- ./col MP start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Madhya Pradesh</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://mp.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://mp.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col Mp end -->
      
       <!-- ./col Gujarat Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Gujarat</h2></div>
          <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://gujarat.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>  
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://gujarat.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col gujarat end-->
      
       <!-- ./col Kerala start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Kerala</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://kerala.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>  
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://kerala.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col kerala end -->
      
       <!-- ./col karanataka start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Karnataka</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://karnataka.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://karnataka.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col karnataka end -->
      
    <!-- 3rd row end-->  
    
    
     <!--4th row start-->
     <!-- ./col tamilnadu start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Tamilnadu</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://tamilnadu.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>  
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://tamilnadu.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col tamilnadu end -->
      
       <!-- ./col andhra Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Andhra</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://andhra.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://andhra.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col andhra end-->
      
       <!-- ./col mizoram start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Mizoram</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://mizoram.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div> 
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://mizoram.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col mizoram end -->
      
       <!-- ./col tripura start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Tripura</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://tripura.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>  
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://tripura.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col tripura end -->
     <!--4th row end-->
     
      <!--5th row start-->
      <!-- ./col jharkhand start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Jharkhand</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://jharkhand.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://jharkhand.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col jharkhand end -->
       <!-- ./col assam Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Assam</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://assam.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div> 
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://assam.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col assam end-->
      
       <!-- ./col manipur start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Manipur</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://manipur.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://manipur.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col manipur end -->
      
       <!-- ./col Meghalaya start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Meghalaya</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://meghalaya.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://meghalaya.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col Meghalaya end -->
      
      <!---5th row end-->
      <!--6th row start-->
      <!-- ./col west bengal start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>West Bengal</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://westbengal.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://westbengal.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col West Bengal end -->
      
       <!-- ./col Odisha Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Odisha</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://odisha.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://odisha.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col odisha end-->
       <!-- ./col Jandk start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Jammu & Kashmir</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://jandk.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://jandk.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col jandk end -->
      
       <!-- ./col himachal start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Himachal</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://himachal.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://himachal.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col himachal end -->
      <!--6th row end-->
      
      <!--7th row start-->
      <!-- ./col up start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Uttar Pradesh</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://upgov.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://upgov.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col up end -->
       <!-- ./col rajasthan Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Rajasthan</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://rajasthan.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div> 
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://rajasthan.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col rajasthan end-->
       <!-- ./col arunachal start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Arunachal Pradesh</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://arunachal.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://arunachal.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col arunachal end -->
      
       <!-- ./col uk start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Uttrakhand</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://uk.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>  
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://uk.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col uk end -->
      <!--7th row end-->
      
      <!--8th row start-->
      <!-- ./col sikkim start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Sikkim</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://sikkim.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://sikkim.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col sikkim end -->
      
       <!-- ./col Delhi Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Delhi</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://delhi.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>  
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://delhi.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col delhi end-->
      
       <!-- ./col ut start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>UT</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://ut.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://ut.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col ut end -->
      
         <!-- ./col chhattisgarh start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Chhattisgarh</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://chhattisgarh.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://chhattisgarh.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col chhattisgarh end -->
      
      <!--8th row end-->
     <!--9th row start-->
     
      <!-- ./col Nagaland start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Nagaland</h2></div>
            <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://nagaland.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://nagaland.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col nagaland end -->
       <!-- ./col telangana start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Telangana</h2></div>
           <div class="alldashdetail">
            <div class="inner">
         <iframe sandbox="allow-forms allow-same-origin allow-scripts" src="http://telangana.attendance.gov.in/" height="70" frameborder="0"></iframe> 
           
          </div>
            
                </div>   
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://telangana.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col telangana end -->
    </div>
    </div>
    <!-- /.row --> 
    
    <!-- top row -->
    <div class="row"> 
      <!-- Left col --> 
      <!-- /.Left col --> 
      
	
      <center><h6> Beta Version | Best viewed on Chrome, Firefox, Explorer 11 and above | E-Mail: helpdesk-attendance[@]gov.in | Helpline <img src="<?php echo base_url(); ?>assets/img/phone.jpg" width="30" height="40" alt="phoneimage" > 011-27003511 <br/>
		&copy; <?php echo date('Y'); ?> Attendance.gov.in. All rights reserved.</h6></center>

  </div>
    <!-- /.row --> 
    
    <!-- graph section --> 
    
  </section>
  <!-- /.content --> 
</aside>
<!-- /.right-side -->
</div>
<!-- ./wrapper -->
<?php //$this->load->view('../../__inc/public_foot');?>
 <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/site/app.js" type="text/javascript"></script>
       <!--<script type="text/javascript" src="<?php echo base_url();?>assets/js/highcharts.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/site/countUp.min.js" type="text/javascript"></script>  
        <script type="text/javascript" src="<?php echo base_url();?>assets/js/site/alldashboard.js" type="text/javascript"></script>-->




<!-- add new calendar event modal -->

</body></html>