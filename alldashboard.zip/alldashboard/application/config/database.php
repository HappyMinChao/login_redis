<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
| DATABASE CONNECTIVITY SETTINGS
| -------------------------------------------------------------------
| This file will contain the settings needed to access your database.
|
| For complete instructions please consult the 'Database Connection'
| page of the User Guide.
|
| -------------------------------------------------------------------
| EXPLANATION OF VARIABLES
| -------------------------------------------------------------------
|
|	['hostname'] The hostname of your database server.
|	['username'] The username used to connect to the database
|	['password'] The password used to connect to the database
|	['database'] The name of the database you want to connect to
|	['dbdriver'] The database type. ie: mysql.  Currently supported:
				 mysql, mysqli, postgre, odbc, mssql, sqlite, oci8
|	['dbprefix'] You can add an optional prefix, which will be added
|				 to the table name when using the  Active Record class
|	['pconnect'] TRUE/FALSE - Whether to use a persistent connection
|	['db_debug'] TRUE/FALSE - Whether database errors should be displayed.
|	['cache_on'] TRUE/FALSE - Enables/disables query caching
|	['cachedir'] The path to the folder where cache files should be stored
|	['char_set'] The character set used in communicating with the database
|	['dbcollat'] The character collation used in communicating with the database
|				 NOTE: For MySQL and MySQLi databases, this setting is only used
| 				 as a backup if your server is running PHP < 5.2.3 or MySQL < 5.0.7
|				 (and in table creation queries made with DB Forge).
| 				 There is an incompatibility in PHP with mysql_real_escape_string() which
| 				 can make your site vulnerable to SQL injection if you are using a
| 				 multi-byte character set and are running versions lower than these.
| 				 Sites using Latin-1 or UTF-8 database character set and collation are unaffected.
|	['swap_pre'] A default table prefix that should be swapped with the dbprefix
|	['autoinit'] Whether or not to automatically initialize the database.
|	['stricton'] TRUE/FALSE - forces 'Strict Mode' connections
|							- good for ensuring strict SQL while developing
|
| The $active_group variable lets you choose which connection group to
| make active.  By default there is only one group (the 'default' group).
|
| The $active_record variables lets you determine whether or not to load
| the active record class
*/

$active_group = 'vi';
$active_record = TRUE;


$db['vi']['hostname'] = '10.249.35.37';
$db['vi']['username'] = 'app_usr1';
$db['vi']['password'] = 'And$baS@321';
$db['vi']['database'] = 'attendance_app';
$db['vi']['dbdriver'] = 'mysql';
$db['vi']['dbprefix'] = '';
$db['vi']['pconnect'] = FALSE;
$db['vi']['db_debug'] = TRUE;
$db['vi']['cache_on'] = FALSE;
$db['vi']['cachedir'] = '';
$db['vi']['char_set'] = 'utf8';
$db['vi']['dbcollat'] = 'utf8_general_ci';
$db['vi']['swap_pre'] = '';
$db['vi']['autoinit'] = TRUE;
$db['vi']['stricton'] = FALSE;


//Added by Khabiruddin
//Central
$db['central']['hostname'] = '127.0.0.1';
$db['central']['username'] = 'root';
$db['central']['password'] = '';
$db['central']['database'] = 'attendance_app2';
$db['central']['dbdriver'] = 'mysql';
$db['central']['dbprefix'] = '';
$db['central']['pconnect'] = FALSE;
$db['central']['db_debug'] = TRUE;
$db['central']['cache_on'] = FALSE;
$db['central']['cachedir'] = '';
$db['central']['char_set'] = 'utf8';
$db['central']['dbcollat'] = 'utf8_general_ci';
$db['central']['swap_pre'] = '';
$db['central']['autoinit'] = TRUE;
$db['central']['stricton'] = FALSE;

//Haryana
$db['hr']['hostname'] = '127.0.0.1';
$db['hr']['username'] = 'root';
$db['hr']['password'] = '';
$db['hr']['database'] = 'attendance_app2';
$db['hr']['dbdriver'] = 'mysql';
$db['hr']['dbprefix'] = '';
$db['hr']['pconnect'] = FALSE;
$db['hr']['db_debug'] = TRUE;
$db['hr']['cache_on'] = FALSE;
$db['hr']['cachedir'] = '';
$db['hr']['char_set'] = 'utf8';
$db['hr']['dbcollat'] = 'utf8_general_ci';
$db['hr']['swap_pre'] = '';
$db['hr']['autoinit'] = TRUE;
$db['hr']['stricton'] = FALSE;
//chandigarh
$db['chandigarh']['hostname'] = '127.0.0.1';
$db['chandigarh']['username'] = 'root';
$db['chandigarh']['password'] = '';
$db['chandigarh']['database'] = 'attendance_app2';
$db['chandigarh']['dbdriver'] = 'mysql';
$db['chandigarh']['dbprefix'] = '';
$db['chandigarh']['pconnect'] = FALSE;
$db['chandigarh']['db_debug'] = TRUE;
$db['chandigarh']['cache_on'] = FALSE;
$db['chandigarh']['cachedir'] = '';
$db['chandigarh']['char_set'] = 'utf8';
$db['chandigarh']['dbcollat'] = 'utf8_general_ci';
$db['chandigarh']['swap_pre'] = '';
$db['chandigarh']['autoinit'] = TRUE;
$db['chandigarh']['stricton'] = FALSE;
//Maharashtra
$db['maharashtra']['hostname'] = '127.0.0.1';
$db['maharashtra']['username'] = 'root';
$db['maharashtra']['password'] = '';
$db['maharashtra']['database'] = 'attendance_app2';
$db['maharashtra']['dbdriver'] = 'mysql';
$db['maharashtra']['dbprefix'] = '';
$db['maharashtra']['pconnect'] = FALSE;
$db['maharashtra']['db_debug'] = TRUE;
$db['maharashtra']['cache_on'] = FALSE;
$db['maharashtra']['cachedir'] = '';
$db['maharashtra']['char_set'] = 'utf8';
$db['maharashtra']['dbcollat'] = 'utf8_general_ci';
$db['maharashtra']['swap_pre'] = '';
$db['maharashtra']['autoinit'] = TRUE;
$db['maharashtra']['stricton'] = FALSE;
//Bihar
$db['bihar']['hostname'] = '127.0.0.1';
$db['bihar']['username'] = 'root';
$db['bihar']['password'] = '';
$db['bihar']['database'] = 'attendance_app2';
$db['bihar']['dbdriver'] = 'mysql';
$db['bihar']['dbprefix'] = '';
$db['bihar']['pconnect'] = FALSE;
$db['bihar']['db_debug'] = TRUE;
$db['bihar']['cache_on'] = FALSE;
$db['bihar']['cachedir'] = '';
$db['bihar']['char_set'] = 'utf8';
$db['bihar']['dbcollat'] = 'utf8_general_ci';
$db['bihar']['swap_pre'] = '';
$db['bihar']['autoinit'] = TRUE;
$db['bihar']['stricton'] = FALSE;

//Goa
$db['goa']['hostname'] = '127.0.0.1';
$db['goa']['username'] = 'root';
$db['goa']['password'] = '';
$db['goa']['database'] = 'attendance_app2';
$db['goa']['dbdriver'] = 'mysql';
$db['goa']['dbprefix'] = '';
$db['goa']['pconnect'] = FALSE;
$db['goa']['db_debug'] = TRUE;
$db['goa']['cache_on'] = FALSE;
$db['goa']['cachedir'] = '';
$db['goa']['char_set'] = 'utf8';
$db['goa']['dbcollat'] = 'utf8_general_ci';
$db['goa']['swap_pre'] = '';
$db['goa']['autoinit'] = TRUE;
$db['goa']['stricton'] = FALSE;

//Punjab
$db['punjab']['hostname'] = '127.0.0.1';
$db['punjab']['username'] = 'root';
$db['punjab']['password'] = '';
$db['punjab']['database'] = 'attendance_app2';
$db['punjab']['dbdriver'] = 'mysql';
$db['punjab']['dbprefix'] = '';
$db['punjab']['pconnect'] = FALSE;
$db['punjab']['db_debug'] = TRUE;
$db['punjab']['cache_on'] = FALSE;
$db['punjab']['cachedir'] = '';
$db['punjab']['char_set'] = 'utf8';
$db['punjab']['dbcollat'] = 'utf8_general_ci';
$db['punjab']['swap_pre'] = '';
$db['punjab']['autoinit'] = TRUE;
$db['punjab']['stricton'] = FALSE;
//MP
$db['mp']['hostname'] = '127.0.0.1';
$db['mp']['username'] = 'root';
$db['mp']['password'] = '';
$db['mp']['database'] = 'attendance_app2';
$db['mp']['dbdriver'] = 'mysql';
$db['mp']['dbprefix'] = '';
$db['mp']['pconnect'] = FALSE;
$db['mp']['db_debug'] = TRUE;
$db['mp']['cache_on'] = FALSE;
$db['mp']['cachedir'] = '';
$db['mp']['char_set'] = 'utf8';
$db['mp']['dbcollat'] = 'utf8_general_ci';
$db['mp']['swap_pre'] = '';
$db['mp']['autoinit'] = TRUE;
$db['mp']['stricton'] = FALSE;
//gujarat
$db['gujarat']['hostname'] = '127.0.0.1';
$db['gujarat']['username'] = 'root';
$db['gujarat']['password'] = '';
$db['gujarat']['database'] = 'attendance_app2';
$db['gujarat']['dbdriver'] = 'mysql';
$db['gujarat']['dbprefix'] = '';
$db['gujarat']['pconnect'] = FALSE;
$db['gujarat']['db_debug'] = TRUE;
$db['gujarat']['cache_on'] = FALSE;
$db['gujarat']['cachedir'] = '';
$db['gujarat']['char_set'] = 'utf8';
$db['gujarat']['dbcollat'] = 'utf8_general_ci';
$db['gujarat']['swap_pre'] = '';
$db['gujarat']['autoinit'] = TRUE;
$db['gujarat']['stricton'] = FALSE;

//kerala
$db['kerala']['hostname'] = '127.0.0.1';
$db['kerala']['username'] = 'root';
$db['kerala']['password'] = '';
$db['kerala']['database'] = 'attendance_app2';
$db['kerala']['dbdriver'] = 'mysql';
$db['kerala']['dbprefix'] = '';
$db['kerala']['pconnect'] = FALSE;
$db['kerala']['db_debug'] = TRUE;
$db['kerala']['cache_on'] = FALSE;
$db['kerala']['cachedir'] = '';
$db['kerala']['char_set'] = 'utf8';
$db['kerala']['dbcollat'] = 'utf8_general_ci';
$db['kerala']['swap_pre'] = '';
$db['kerala']['autoinit'] = TRUE;
$db['kerala']['stricton'] = FALSE;

//karnataka
$db['karnataka']['hostname'] = '127.0.0.1';
$db['karnataka']['username'] = 'root';
$db['karnataka']['password'] = '';
$db['karnataka']['database'] = 'attendance_app2';
$db['karnataka']['dbdriver'] = 'mysql';
$db['karnataka']['dbprefix'] = '';
$db['karnataka']['pconnect'] = FALSE;
$db['karnataka']['db_debug'] = TRUE;
$db['karnataka']['cache_on'] = FALSE;
$db['karnataka']['cachedir'] = '';
$db['karnataka']['char_set'] = 'utf8';
$db['karnataka']['dbcollat'] = 'utf8_general_ci';
$db['karnataka']['swap_pre'] = '';
$db['karnataka']['autoinit'] = TRUE;
$db['karnataka']['stricton'] = FALSE;

//tamilnadu
$db['tamilnadu']['hostname'] = '127.0.0.1';
$db['tamilnadu']['username'] = 'root';
$db['tamilnadu']['password'] = '';
$db['tamilnadu']['database'] = 'attendance_app2';
$db['tamilnadu']['dbdriver'] = 'mysql';
$db['tamilnadu']['dbprefix'] = '';
$db['tamilnadu']['pconnect'] = FALSE;
$db['tamilnadu']['db_debug'] = TRUE;
$db['tamilnadu']['cache_on'] = FALSE;
$db['tamilnadu']['cachedir'] = '';
$db['tamilnadu']['char_set'] = 'utf8';
$db['tamilnadu']['dbcollat'] = 'utf8_general_ci';
$db['tamilnadu']['swap_pre'] = '';
$db['tamilnadu']['autoinit'] = TRUE;
$db['tamilnadu']['stricton'] = FALSE;

//andhra
$db['andhra']['hostname'] = '127.0.0.1';
$db['andhra']['username'] = 'root';
$db['andhra']['password'] = '';
$db['andhra']['database'] = 'attendance_app2';
$db['andhra']['dbdriver'] = 'mysql';
$db['andhra']['dbprefix'] = '';
$db['andhra']['pconnect'] = FALSE;
$db['andhra']['db_debug'] = TRUE;
$db['andhra']['cache_on'] = FALSE;
$db['andhra']['cachedir'] = '';
$db['andhra']['char_set'] = 'utf8';
$db['andhra']['dbcollat'] = 'utf8_general_ci';
$db['andhra']['swap_pre'] = '';
$db['andhra']['autoinit'] = TRUE;
$db['andhra']['stricton'] = FALSE;

//mizoram
$db['mizoram']['hostname'] = '127.0.0.1';
$db['mizoram']['username'] = 'root';
$db['mizoram']['password'] = '';
$db['mizoram']['database'] = 'attendance_app2';
$db['mizoram']['dbdriver'] = 'mysql';
$db['mizoram']['dbprefix'] = '';
$db['mizoram']['pconnect'] = FALSE;
$db['mizoram']['db_debug'] = TRUE;
$db['mizoram']['cache_on'] = FALSE;
$db['mizoram']['cachedir'] = '';
$db['mizoram']['char_set'] = 'utf8';
$db['mizoram']['dbcollat'] = 'utf8_general_ci';
$db['mizoram']['swap_pre'] = '';
$db['mizoram']['autoinit'] = TRUE;
$db['mizoram']['stricton'] = FALSE;

//tripura
$db['tripura']['hostname'] = '127.0.0.1';
$db['tripura']['username'] = 'root';
$db['tripura']['password'] = '';
$db['tripura']['database'] = 'attendance_app2';
$db['tripura']['dbdriver'] = 'mysql';
$db['tripura']['dbprefix'] = '';
$db['tripura']['pconnect'] = FALSE;
$db['tripura']['db_debug'] = TRUE;
$db['tripura']['cache_on'] = FALSE;
$db['tripura']['cachedir'] = '';
$db['tripura']['char_set'] = 'utf8';
$db['tripura']['dbcollat'] = 'utf8_general_ci';
$db['tripura']['swap_pre'] = '';
$db['tripura']['autoinit'] = TRUE;
$db['tripura']['stricton'] = FALSE;

//jharkhand
$db['jharkhand']['hostname'] = '127.0.0.1';
$db['jharkhand']['username'] = 'root';
$db['jharkhand']['password'] = '';
$db['jharkhand']['database'] = 'attendance_app2';
$db['jharkhand']['dbdriver'] = 'mysql';
$db['jharkhand']['dbprefix'] = '';
$db['jharkhand']['pconnect'] = FALSE;
$db['jharkhand']['db_debug'] = TRUE;
$db['jharkhand']['cache_on'] = FALSE;
$db['jharkhand']['cachedir'] = '';
$db['jharkhand']['char_set'] = 'utf8';
$db['jharkhand']['dbcollat'] = 'utf8_general_ci';
$db['jharkhand']['swap_pre'] = '';
$db['jharkhand']['autoinit'] = TRUE;
$db['jharkhand']['stricton'] = FALSE;

//assam
$db['assam']['hostname'] = '127.0.0.1';
$db['assam']['username'] = 'root';
$db['assam']['password'] = '';
$db['assam']['database'] = 'attendance_app2';
$db['assam']['dbdriver'] = 'mysql';
$db['assam']['dbprefix'] = '';
$db['assam']['pconnect'] = FALSE;
$db['assam']['db_debug'] = TRUE;
$db['assam']['cache_on'] = FALSE;
$db['assam']['cachedir'] = '';
$db['assam']['char_set'] = 'utf8';
$db['assam']['dbcollat'] = 'utf8_general_ci';
$db['assam']['swap_pre'] = '';
$db['assam']['autoinit'] = TRUE;
$db['assam']['stricton'] = FALSE;

//manipur
$db['manipur']['hostname'] = '127.0.0.1';
$db['manipur']['username'] = 'root';
$db['manipur']['password'] = '';
$db['manipur']['database'] = 'attendance_app2';
$db['manipur']['dbdriver'] = 'mysql';
$db['manipur']['dbprefix'] = '';
$db['manipur']['pconnect'] = FALSE;
$db['manipur']['db_debug'] = TRUE;
$db['manipur']['cache_on'] = FALSE;
$db['manipur']['cachedir'] = '';
$db['manipur']['char_set'] = 'utf8';
$db['manipur']['dbcollat'] = 'utf8_general_ci';
$db['manipur']['swap_pre'] = '';
$db['manipur']['autoinit'] = TRUE;
$db['manipur']['stricton'] = FALSE;
//meghalaya
$db['meghalaya']['hostname'] = '127.0.0.1';
$db['meghalaya']['username'] = 'root';
$db['meghalaya']['password'] = '';
$db['meghalaya']['database'] = 'attendance_app2';
$db['meghalaya']['dbdriver'] = 'mysql';
$db['meghalaya']['dbprefix'] = '';
$db['meghalaya']['pconnect'] = FALSE;
$db['meghalaya']['db_debug'] = TRUE;
$db['meghalaya']['cache_on'] = FALSE;
$db['meghalaya']['cachedir'] = '';
$db['meghalaya']['char_set'] = 'utf8';
$db['meghalaya']['dbcollat'] = 'utf8_general_ci';
$db['meghalaya']['swap_pre'] = '';
$db['meghalaya']['autoinit'] = TRUE;
$db['meghalaya']['stricton'] = FALSE;

//West bengal
$db['wb']['hostname'] = '127.0.0.1';
$db['wb']['username'] = 'root';
$db['wb']['password'] = '';
$db['wb']['database'] = 'attendance_app2';
$db['wb']['dbdriver'] = 'mysql';
$db['wb']['dbprefix'] = '';
$db['wb']['pconnect'] = FALSE;
$db['wb']['db_debug'] = TRUE;
$db['wb']['cache_on'] = FALSE;
$db['wb']['cachedir'] = '';
$db['wb']['char_set'] = 'utf8';
$db['wb']['dbcollat'] = 'utf8_general_ci';
$db['wb']['swap_pre'] = '';
$db['wb']['autoinit'] = TRUE;
$db['wb']['stricton'] = FALSE;

//odisha
$db['odisha']['hostname'] = '127.0.0.1';
$db['odisha']['username'] = 'root';
$db['odisha']['password'] = '';
$db['odisha']['database'] = 'attendance_app2';
$db['odisha']['dbdriver'] = 'mysql';
$db['odisha']['dbprefix'] = '';
$db['odisha']['pconnect'] = FALSE;
$db['odisha']['db_debug'] = TRUE;
$db['odisha']['cache_on'] = FALSE;
$db['odisha']['cachedir'] = '';
$db['odisha']['char_set'] = 'utf8';
$db['odisha']['dbcollat'] = 'utf8_general_ci';
$db['odisha']['swap_pre'] = '';
$db['odisha']['autoinit'] = TRUE;
$db['odisha']['stricton'] = FALSE;

//J&K
$db['jk']['hostname'] = '127.0.0.1';
$db['jk']['username'] = 'root';
$db['jk']['password'] = '';
$db['jk']['database'] = 'attendance_app2';
$db['jk']['dbdriver'] = 'mysql';
$db['jk']['dbprefix'] = '';
$db['jk']['pconnect'] = FALSE;
$db['jk']['db_debug'] = TRUE;
$db['jk']['cache_on'] = FALSE;
$db['jk']['cachedir'] = '';
$db['jk']['char_set'] = 'utf8';
$db['jk']['dbcollat'] = 'utf8_general_ci';
$db['jk']['swap_pre'] = '';
$db['jk']['autoinit'] = TRUE;
$db['jk']['stricton'] = FALSE;

//hinachal
$db['himachal']['hostname'] = '127.0.0.1';
$db['himachal']['username'] = 'root';
$db['himachal']['password'] = '';
$db['himachal']['database'] = 'attendance_app2';
$db['himachal']['dbdriver'] = 'mysql';
$db['himachal']['dbprefix'] = '';
$db['himachal']['pconnect'] = FALSE;
$db['himachal']['db_debug'] = TRUE;
$db['himachal']['cache_on'] = FALSE;
$db['himachal']['cachedir'] = '';
$db['himachal']['char_set'] = 'utf8';
$db['himachal']['dbcollat'] = 'utf8_general_ci';
$db['himachal']['swap_pre'] = '';
$db['himachal']['autoinit'] = TRUE;
$db['himachal']['stricton'] = FALSE;

//UP
$db['up']['hostname'] = '127.0.0.1';
$db['up']['username'] = 'root';
$db['up']['password'] = '';
$db['up']['database'] = 'attendance_app2';
$db['up']['dbdriver'] = 'mysql';
$db['up']['dbprefix'] = '';
$db['up']['pconnect'] = FALSE;
$db['up']['db_debug'] = TRUE;
$db['up']['cache_on'] = FALSE;
$db['up']['cachedir'] = '';
$db['up']['char_set'] = 'utf8';
$db['up']['dbcollat'] = 'utf8_general_ci';
$db['up']['swap_pre'] = '';
$db['up']['autoinit'] = TRUE;
$db['up']['stricton'] = FALSE;

//rajasthan
$db['raj']['hostname'] = '127.0.0.1';
$db['raj']['username'] = 'root';
$db['raj']['password'] = '';
$db['raj']['database'] = 'attendance_app2';
$db['raj']['dbdriver'] = 'mysql';
$db['raj']['dbprefix'] = '';
$db['raj']['pconnect'] = FALSE;
$db['raj']['db_debug'] = TRUE;
$db['raj']['cache_on'] = FALSE;
$db['raj']['cachedir'] = '';
$db['raj']['char_set'] = 'utf8';
$db['raj']['dbcollat'] = 'utf8_general_ci';
$db['raj']['swap_pre'] = '';
$db['raj']['autoinit'] = TRUE;
$db['raj']['stricton'] = FALSE;

//arunachal
$db['arunachal']['hostname'] = '127.0.0.1';
$db['arunachal']['username'] = 'root';
$db['arunachal']['password'] = '';
$db['arunachal']['database'] = 'attendance_app2';
$db['arunachal']['dbdriver'] = 'mysql';
$db['arunachal']['dbprefix'] = '';
$db['arunachal']['pconnect'] = FALSE;
$db['arunachal']['db_debug'] = TRUE;
$db['arunachal']['cache_on'] = FALSE;
$db['arunachal']['cachedir'] = '';
$db['arunachal']['char_set'] = 'utf8';
$db['arunachal']['dbcollat'] = 'utf8_general_ci';
$db['arunachal']['swap_pre'] = '';
$db['arunachal']['autoinit'] = TRUE;
$db['arunachal']['stricton'] = FALSE;

//UK
$db['uk']['hostname'] = '127.0.0.1';
$db['uk']['username'] = 'root';
$db['uk']['password'] = '';
$db['uk']['database'] = 'attendance_app2';
$db['uk']['dbdriver'] = 'mysql';
$db['uk']['dbprefix'] = '';
$db['uk']['pconnect'] = FALSE;
$db['uk']['db_debug'] = TRUE;
$db['uk']['cache_on'] = FALSE;
$db['uk']['cachedir'] = '';
$db['uk']['char_set'] = 'utf8';
$db['uk']['dbcollat'] = 'utf8_general_ci';
$db['uk']['swap_pre'] = '';
$db['uk']['autoinit'] = TRUE;
$db['uk']['stricton'] = FALSE;

//sikkim
$db['sikkim']['hostname'] = '127.0.0.1';
$db['sikkim']['username'] = 'root';
$db['sikkim']['password'] = '';
$db['sikkim']['database'] = 'attendance_app2';
$db['sikkim']['dbdriver'] = 'mysql';
$db['sikkim']['dbprefix'] = '';
$db['sikkim']['pconnect'] = FALSE;
$db['sikkim']['db_debug'] = TRUE;
$db['sikkim']['cache_on'] = FALSE;
$db['sikkim']['cachedir'] = '';
$db['sikkim']['char_set'] = 'utf8';
$db['sikkim']['dbcollat'] = 'utf8_general_ci';
$db['sikkim']['swap_pre'] = '';
$db['sikkim']['autoinit'] = TRUE;
$db['sikkim']['stricton'] = FALSE;

//Delhi
$db['delhi']['hostname'] = '127.0.0.1';
$db['delhi']['username'] = 'root';
$db['delhi']['password'] = '';
$db['delhi']['database'] = 'attendance_app2';
$db['delhi']['dbdriver'] = 'mysql';
$db['delhi']['dbprefix'] = '';
$db['delhi']['pconnect'] = FALSE;
$db['delhi']['db_debug'] = TRUE;
$db['delhi']['cache_on'] = FALSE;
$db['delhi']['cachedir'] = '';
$db['delhi']['char_set'] = 'utf8';
$db['delhi']['dbcollat'] = 'utf8_general_ci';
$db['delhi']['swap_pre'] = '';
$db['delhi']['autoinit'] = TRUE;
$db['delhi']['stricton'] = FALSE;

//UT
$db['ut']['hostname'] = '127.0.0.1';
$db['ut']['username'] = 'root';
$db['ut']['password'] = '';
$db['ut']['database'] = 'attendance_app2';
$db['ut']['dbdriver'] = 'mysql';
$db['ut']['dbprefix'] = '';
$db['ut']['pconnect'] = FALSE;
$db['ut']['db_debug'] = TRUE;
$db['ut']['cache_on'] = FALSE;
$db['ut']['cachedir'] = '';
$db['ut']['char_set'] = 'utf8';
$db['ut']['dbcollat'] = 'utf8_general_ci';
$db['ut']['swap_pre'] = '';
$db['ut']['autoinit'] = TRUE;
$db['ut']['stricton'] = FALSE;

//Chhattisgarh
$db['chhattisgarh']['hostname'] = '127.0.0.1';
$db['chhattisgarh']['username'] = 'root';
$db['chhattisgarh']['password'] = '';
$db['chhattisgarh']['database'] = 'attendance_app2';
$db['chhattisgarh']['dbdriver'] = 'mysql';
$db['chhattisgarh']['dbprefix'] = '';
$db['chhattisgarh']['pconnect'] = FALSE;
$db['chhattisgarh']['db_debug'] = TRUE;
$db['chhattisgarh']['cache_on'] = FALSE;
$db['chhattisgarh']['cachedir'] = '';
$db['chhattisgarh']['char_set'] = 'utf8';
$db['chhattisgarh']['dbcollat'] = 'utf8_general_ci';
$db['chhattisgarh']['swap_pre'] = '';
$db['chhattisgarh']['autoinit'] = TRUE;
$db['chhattisgarh']['stricton'] = FALSE;

//Nagaland
$db['nagaland']['hostname'] = '127.0.0.1';
$db['nagaland']['username'] = 'root';
$db['nagaland']['password'] = '';
$db['nagaland']['database'] = 'attendance_app2';
$db['nagaland']['dbdriver'] = 'mysql';
$db['nagaland']['dbprefix'] = '';
$db['nagaland']['pconnect'] = FALSE;
$db['nagaland']['db_debug'] = TRUE;
$db['nagaland']['cache_on'] = FALSE;
$db['nagaland']['cachedir'] = '';
$db['nagaland']['char_set'] = 'utf8';
$db['nagaland']['dbcollat'] = 'utf8_general_ci';
$db['nagaland']['swap_pre'] = '';
$db['nagaland']['autoinit'] = TRUE;
$db['nagaland']['stricton'] = FALSE;

//telangana
$db['telangana']['hostname'] = '127.0.0.1';
$db['telangana']['username'] = 'root';
$db['telangana']['password'] = '';
$db['telangana']['database'] = 'attendance_app2';
$db['telangana']['dbdriver'] = 'mysql';
$db['telangana']['dbprefix'] = '';
$db['telangana']['pconnect'] = FALSE;
$db['telangana']['db_debug'] = TRUE;
$db['telangana']['cache_on'] = FALSE;
$db['telangana']['cachedir'] = '';
$db['telangana']['char_set'] = 'utf8';
$db['telangana']['dbcollat'] = 'utf8_general_ci';
$db['telangana']['swap_pre'] = '';
$db['telangana']['autoinit'] = TRUE;
$db['telangana']['stricton'] = FALSE;
/* End of file database.php */
/* Location: ./application/config/database.php */