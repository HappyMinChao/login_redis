
<?php
include("Crypt/Random.php");
include("Crypt/RSA.php");
include('padCrypt.php');
include('AES_Encryption.php');

$db         = mysql_connect('10.249.35.40', 'root', 'redhat');
$mysql_conn = mysql_select_db('app_demo', $db);
$sno='';
$err=0;

$sender = $_GET['Sender'];

$destination = $_GET['Destination'];
$message = explode(" ",$_GET['Message']);
$created_date = $_GET['Time'];

$prefix='91';
if (substr($sender, 0, strlen($prefix)) == $prefix) {
    $sender = substr($sender, strlen($prefix));
}
if (substr($destination, 0, strlen($prefix)) == $prefix) {
    $destination = substr($destination, strlen($prefix));
}
$otp= trim($message[0],' ');
$aadhaar= trim($message[1],' ');
if(strlen($aadhaar)!=12)
{
	$err=1;
}
if(strlen($otp)!=6)
{
	$err=1;
}if(empty($sender)|| empty($destination) || empty($created_date) || empty($otp)|| empty($aadhaar))
{
	$err=1;
}



if($err==1)
{
	exit;
	die;
}
else
{
$ins_qry  = mysql_query("insert into log_sms(sender,destination,aadhaar,otp,created_date) values('$sender','$destination','$aadhaar','$otp','$created_date')");
}
//echo $sender.'--'.$destination.'--'.$created_date.'--'.$otp.'--'.$aadhaar;die;


$sel_qry  = mysql_query("select * from update_aadhaar where otp='$otp'");
$sel_data=mysql_fetch_assoc($sel_qry);
$sno=$sel_data['sno'];
$name=$sel_data['name'];
$aadhaar_db=$sel_data['aadhaar'];

if(!empty($aadhaar_db))
{
$msg = 'Dear Sir/Madam,Your aadhaar is already updated with us. Regards,jeevanpramaan.gov.in Team';	
$subject = 'Your aadhaar updation Info';	
send_sms_msg($sender ,$msg); //remove comment later
	
}

//echo "SNO--".$sno.'Error--'.$err;
if($sno && ($err==0) && empty($aadhaar_db))
{

//auth demo starts

$pub_key = openssl_pkey_get_public(file_get_contents('uidai_auth_prod.cer'));
$keyData = openssl_pkey_get_details($pub_key);
$pubKey = $keyData['key'];
$ci         = openssl_x509_parse(file_get_contents('uidai_auth_prod.cer'));
$validFrom  = date('Ymd', $ci['validTo_time_t']);
$keyLen = 24;

$sessionKey = base64_encode(crypt_random_string($keyLen));

$rsaCrypt = new Crypt_RSA();

$rsaCrypt->loadKey($pubKey);
$rsaCrypt->setEncryptionMode(CRYPT_RSA_ENCRYPTION_PKCS1);

$encSessionKey = base64_encode($rsaCrypt->encrypt($sessionKey));

$pidBlock = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
$pidBlock .= '<ns2:Pid ts="';
$pidBlock .= date("Y-m-d"). 'T' . date('h:i:s');
$pidBlock .= '" xmlns:ns2="http://www.uidai.gov.in/authentication/uid-auth-request-data/1.0"><Demo xmlns="http://www.uidai.gov.in/authentication/uid-auth-request-data/1.0">
<Pi ms="P" mv="100" name="';
$pidBlock .= $name;
$pidBlock .= '" /></Demo></ns2:Pid>';

$aes = new AES_Encryption($sessionKey, 0, 'PKCS7', 'ecb' );

$encPidBlock = base64_encode($aes->encrypt($pidBlock));

$hashGenerator = new Crypt_Hash('sha256');
$hmac = $hashGenerator->hash($pidBlock);

$encHmac = base64_encode($aes->encrypt($hmac));
 $txn_val = $aadhaar . '^' . $name;
 $txn_hash = sha1($txn_val, false);
 
$authXml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Auth uid="';
$authXml .= $aadhaar;
$authXml .= '" tid="public" sa="NICDEM" txn="';
$authXml .= $txn_hash;
$authXml .= '" xmlns="http://www.uidai.gov.in/authentication/uid-auth-request/1.0">
<Uses pi="y" pa="n" pfa="n" bio="n" pin="n" otp="n" />
<Meta udc="NICTEST" pip="10.25.72.114" fdc="NC" idc="NA" lot="P" lov="110092" /><Skey ci="' . $validFrom . '">';
$authXml .= $encSessionKey;
$authXml .= '</Skey><Data type="X">';
$authXml .= $encPidBlock;
$authXml .= '</Data><Hmac>';
$authXml .= $encHmac;
$authXml .= '</Hmac></Auth>';

//echo $authXml;

$url = 'http://10.249.34.250:8080/NicASAServer/ASAMain/1.6';
	
        $ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $authXml);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	$result = curl_exec($ch);
	curl_close($ch);
	
	$xml                       = simplexml_load_string($result);
        $ret_val['error']          = (string) $xml->attributes()->err;
        $ret_val['transaction_id'] = (string) $xml->attributes()->txn;
        $ret_val['code']           = (string) $xml->attributes()->code;
        $ret_val['ts']             = (string) $xml->attributes()->ts;
        
//print_r($ret_val);
if(empty($ret_val['error']))
{
$up_qry   = mysql_query("update update_aadhaar set aadhaar='$aadhaar',err_code='$ret_val[error]',ret_demo_auth='Y',recieve_type='S' where otp='$otp' and sno =$sno");
$msg = 'Dear Sir/Madam,Your aadhaar has been successfully updated in Jeevan Pramaan Portal. Regards,jeevanpramaan.gov.in Team';	
$subject = 'Your aadhaar updation Info';	
send_sms_msg($sender ,$msg); //remove comment later

}
else
{
$up_qry   = mysql_query("update update_aadhaar set err_code='$ret_val[error]',ret_demo_auth='N',recieve_type='S' where otp='$otp' and sno =$sno");
$msg = 'Dear Sir/Madam,Please contact Jeevan Pramaan Call Centre at 123456 to update your aadhaar with us. Regards,jeevanpramaan.gov.in Team';	
$subject = 'Your aadhaar updation Info';	
send_sms_msg($sender ,$msg);// remove comment later
	
}


}



function send_sms_msg($to = NULL, $msg = NULL)
    {
        if ($to != NULL) {
            //$this->load->helper('url');
            //$this->load->library('Sms_lib');
            
            $msg = $msg;
            
            
            $user   = 'aebas.auth';
            $pass   = 'Mkt*24nK';
            $mobile = $to;
            $sendID = 'NICSMS';
            $text   = urlencode($msg);
/*             
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "http://smsgw.sms.gov.in/failsafe/HttpLink?username=$user&pin=$pass&message=$text&mnumber=91$mobile&signature=$sendID");
            curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
            $result = curl_exec($ch);
            curl_close($ch); */
           $URL="https://smsgw.sms.gov.in/failsafe/HttpLink";
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$URL);
			$mystring=$URL;
			$findme="https";
			$pos = strpos($mystring, $findme);
			if($pos >-1)
			{
			curl_setopt($ch, CURLOPT_URL,$URL);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,1);
			curl_setopt($ch, CURLOPT_SSLVERSION, 3);
			curl_setopt($ch, CURLOPT_CAINFO,'/etc/pki/tls/certs/smsgw.sms.gov.in.crt');
			}
			else {
			curl_setopt($ch, CURLOPT_URL,$URL);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
			}
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS,"username=$user&pin=$pass&message=$text&mnumber=91$mobile&signature=$sendID");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			 $result =curl_exec($ch);
			 // if (!$result) {
				// echo 'Error, ' . curl_error($ch) . "\n";
				// die;
			// } 
			curl_close($ch);  
            
        } else {
            
        }
    }
?>