
		//console.log(window.location);
            $(function () {
    $(document).ready(function () {
        

	loadbar();	
	setInterval(function () {loadbar();}, 300000);				
	function loadbar(){							
			$.ajax({
                            
                               url: "alldashboard/employeechart", 
			       async: false,
                               dataType: "html",
                               success: function(result) {
								//console.log(result);
                                                               // alert(result);
							var obj = JSON.parse(result);
							animate_count('count_reg',$('#count_reg').html(),parseInt(obj.tot_reg));
							animate_count('count_present',$('#count_present').html(),parseInt(obj.t_in));
						     }
	})
        $.ajax({
            
                            
                               url: "alldashboard/employeechart2", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg2',$('#count_reg2').html(),parseInt(obj.tot_reg));
							animate_count('count_present2',$('#count_present2').html(),parseInt(obj.t_in));
						     }
	})
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart3", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg3',$('#count_reg3').html(),parseInt(obj.tot_reg));
							animate_count('count_present3',$('#count_present3').html(),parseInt(obj.t_in));
						     }
	})
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart4", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg4',$('#count_reg4').html(),parseInt(obj.tot_reg));
							animate_count('count_present4',$('#count_present4').html(),parseInt(obj.t_in));
						     }
	})
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart5", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg5',$('#count_reg5').html(),parseInt(obj.tot_reg));
							animate_count('count_present5',$('#count_present5').html(),parseInt(obj.t_in));
						     }
	})
        
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart6", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg6',$('#count_reg6').html(),parseInt(obj.tot_reg));
							animate_count('count_present6',$('#count_present6').html(),parseInt(obj.t_in));
						     }
	})
        
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart7", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg7',$('#count_reg7').html(),parseInt(obj.tot_reg));
							animate_count('count_present7',$('#count_present7').html(),parseInt(obj.t_in));
						     }
	})
        
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart8", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg8',$('#count_reg8').html(),parseInt(obj.tot_reg));
							animate_count('count_present8',$('#count_present8').html(),parseInt(obj.t_in));
						     }
	})
        
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart9", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg9',$('#count_reg9').html(),parseInt(obj.tot_reg));
							animate_count('count_present9',$('#count_present9').html(),parseInt(obj.t_in));
						     }
	})
        
       
         $.ajax({
            
                            
                               url: "alldashboard/employeechart10", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg10',$('#count_reg10').html(),parseInt(obj.tot_reg));
							animate_count('count_present10',$('#count_present10').html(),parseInt(obj.t_in));
						     }
	})
        
         
         $.ajax({
            
                            
                               url: "alldashboard/employeechart11", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg11',$('#count_reg11').html(),parseInt(obj.tot_reg));
							animate_count('count_present11',$('#count_present11').html(),parseInt(obj.t_in));
						     }
	})
        
           
         $.ajax({
            
                            
                               url: "alldashboard/employeechart12", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg12',$('#count_reg12').html(),parseInt(obj.tot_reg));
							animate_count('count_present12',$('#count_present12').html(),parseInt(obj.t_in));
						     }
	})
        
           
         $.ajax({
            
                            
                               url: "alldashboard/employeechart13", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg13',$('#count_reg13').html(),parseInt(obj.tot_reg));
							animate_count('count_present13',$('#count_present13').html(),parseInt(obj.t_in));
						     }
	})
           
         $.ajax({
            
                            
                               url: "alldashboard/employeechart14", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg14',$('#count_reg14').html(),parseInt(obj.tot_reg));
							animate_count('count_present14',$('#count_present14').html(),parseInt(obj.t_in));
						     }
	})
        
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart15", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg15',$('#count_reg15').html(),parseInt(obj.tot_reg));
							animate_count('count_present15',$('#count_present15').html(),parseInt(obj.t_in));
						     }
	})
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart16", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg16',$('#count_reg16').html(),parseInt(obj.tot_reg));
							animate_count('count_present16',$('#count_present16').html(),parseInt(obj.t_in));
						     }
	})
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart17", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg17',$('#count_reg17').html(),parseInt(obj.tot_reg));
							animate_count('count_present17',$('#count_present17').html(),parseInt(obj.t_in));
						     }
	})
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart18", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg18',$('#count_reg18').html(),parseInt(obj.tot_reg));
							animate_count('count_present18',$('#count_present18').html(),parseInt(obj.t_in));
						     }
	})
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart19", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg19',$('#count_reg19').html(),parseInt(obj.tot_reg));
							animate_count('count_present19',$('#count_present19').html(),parseInt(obj.t_in));
						     }
	})
        
        
         $.ajax({
            
                            
                               url: "alldashboard/employeechart20", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg20',$('#count_reg20').html(),parseInt(obj.tot_reg));
							animate_count('count_present20',$('#count_present20').html(),parseInt(obj.t_in));
						     }
	})
            $.ajax({
            
                            
                               url: "alldashboard/employeechart21", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg21',$('#count_reg21').html(),parseInt(obj.tot_reg));
							animate_count('count_present21',$('#count_present21').html(),parseInt(obj.t_in));
						     }
	}) 
        
             $.ajax({
            
                            
                               url: "alldashboard/employeechart22", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg22',$('#count_reg22').html(),parseInt(obj.tot_reg));
							animate_count('count_present22',$('#count_present22').html(),parseInt(obj.t_in));
						     }
	})
        
             $.ajax({
            
                            
                               url: "alldashboard/employeechart23", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg23',$('#count_reg23').html(),parseInt(obj.tot_reg));
							animate_count('count_present23',$('#count_present23').html(),parseInt(obj.t_in));
						     }
	})
        
             $.ajax({
            
                            
                               url: "alldashboard/employeechart24", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg24',$('#count_reg24').html(),parseInt(obj.tot_reg));
							animate_count('count_present24',$('#count_present24').html(),parseInt(obj.t_in));
						     }
	})
        
             $.ajax({
            
                            
                               url: "alldashboard/employeechart25", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg25',$('#count_reg25').html(),parseInt(obj.tot_reg));
							animate_count('count_present25',$('#count_present25').html(),parseInt(obj.t_in));
						     }
	})
             $.ajax({
            
                            
                               url: "alldashboard/employeechart26", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg26',$('#count_reg26').html(),parseInt(obj.tot_reg));
							animate_count('count_present26',$('#count_present26').html(),parseInt(obj.t_in));
						     }
	})
        
             $.ajax({
            
                            
                               url: "alldashboard/employeechart27", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg27',$('#count_reg27').html(),parseInt(obj.tot_reg));
							animate_count('count_present27',$('#count_present27').html(),parseInt(obj.t_in));
						     }
	})
             $.ajax({
            
                            
                               url: "alldashboard/employeechart28", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg28',$('#count_reg28').html(),parseInt(obj.tot_reg));
							animate_count('count_present28',$('#count_present28').html(),parseInt(obj.t_in));
						     }
	})
        
             $.ajax({
            
                            
                               url: "alldashboard/employeechart29", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg29',$('#count_reg29').html(),parseInt(obj.tot_reg));
							animate_count('count_present29',$('#count_present29').html(),parseInt(obj.t_in));
						     }
	})
        
        
             $.ajax({
            
                            
                               url: "alldashboard/employeechart30", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg30',$('#count_reg30').html(),parseInt(obj.tot_reg));
							animate_count('count_present30',$('#count_present30').html(),parseInt(obj.t_in));
						     }
	})
        
        
        $.ajax({
            
                            
                               url: "alldashboard/employeechart31", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg31',$('#count_reg31').html(),parseInt(obj.tot_reg));
							animate_count('count_present31',$('#count_present31').html(),parseInt(obj.t_in));
						     }
	})
         
         $.ajax({
            
                            
                               url: "alldashboard/employeechart32", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg32',$('#count_reg32').html(),parseInt(obj.tot_reg));
							animate_count('count_present32',$('#count_present32').html(),parseInt(obj.t_in));
						     }
	})
         $.ajax({
            
                            
                               url: "alldashboard/employeechart33", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg33',$('#count_reg33').html(),parseInt(obj.tot_reg));
							animate_count('count_present33',$('#count_present33').html(),parseInt(obj.t_in));
						     }
	})
        
        $.ajax({
            
                            
                               url: "alldashboard/employeechart34", 
			       async: false,
                               dataType: "html",
                              
                               success: function(result) {
								//console.log(result);
                                                              
							var obj = JSON.parse(result);
							animate_count('count_reg34',$('#count_reg34').html(),parseInt(obj.tot_reg));
							animate_count('count_present34',$('#count_present34').html(),parseInt(obj.t_in));
						     }
	})
         
        
        
        
        
	}					

});
});
 var options = {
        useEasing : true, // toggle easing
        useGrouping : true, // 1,000,000 vs 1000000
        separator : ',', // character to use as a separator
        decimal : '.', // character to use as a decimal
    }
    var useOnComplete = false;
    var useEasing = true;
    var useGrouping = true;

    var demo;

    // create instance
    function animate_count(id,start,end) {
        // fire animation
        // var element = document.querySelector('.jumbo');
        demo = new countUp(id, parseInt(start), parseInt(end), 0, 2.5, options);
		demo.start();

    }
