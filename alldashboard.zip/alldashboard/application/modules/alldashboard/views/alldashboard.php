<aside class="right-side" style="margin-left: 0px;"> 
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1> All Dashboards <small> Biometric Attendance System</small> </h1>
    <ol class="breadcrumb">
      <li><a href="<?php echo base_url();?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
    </ol>
  </section>
  
  <!-- Main content -->
  <section class="content"> 
    
    <!-- Small boxes (Stat box) top statistics shorts -->
    <div class="row">
      
     <!--1st row start-->
      <!-- ./col attendance start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Attendance.gov.in</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg"><?php echo $count_reg;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present"><?php echo $count_present;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col attendance end -->
       <!-- ./col central Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Central.attendance</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg2"><?php echo $reg_central;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present2"><?php echo $present_central;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://central.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col central end-->
       <!-- ./col haryana start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Haryana</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg3"><?php echo $reg_haryana;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present3"><?php echo $present_haryana;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://haryana.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col haryana end -->
      
       <!-- ./col chandigarh start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Chandigarh</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg4"><?php echo $reg_chandigarh;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present4"><?php echo $present_chandigarh;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://chandigarh.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col chandigarh end -->
       <!--1st row end-->
       
        <!--2nd row start-->
       <!-- ./col maharashtra start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Maharashtra</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg5"><?php echo $reg_maharashtra;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present5"><?php echo $present_maharashtra;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://maharashtra.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col maharashtra end -->
      
       <!-- ./col bihar start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Bihar</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg6"><?php echo $reg_bihar;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present6"><?php echo $present_bihar;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://bihar.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col bihar end-->
      
      <!-- ./col goa start-->
     <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Goa</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg7"><?php echo $reg_goa;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present7"><?php echo $present_goa;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://goa.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col -->
      
      <!-- ./col punjab start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Punjab</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg8"><?php echo $reg_punjab;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present8"><?php echo $present_punjab;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://punjab.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      
       <!--2nd row end-->
      
      <!--3rd row start-->
      
      <!-- ./col MP start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Madhya Pradesh</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg9"><?php echo $reg_mp;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present9"><?php echo $present_mp;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://mp.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col Mp end -->
      
       <!-- ./col Gujarat Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Gujarat</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg10"><?php echo $reg_gujarat;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present10"><?php echo $present_gujarat;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://gujarat.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col gujarat end-->
      
       <!-- ./col Kerala start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Kerala</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg11"><?php echo $reg_kerala;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present11"><?php echo $present_kerala;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://kerala.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col kerala end -->
      
       <!-- ./col karanataka start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Karnataka</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg12"><?php echo $reg_karnataka;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present12"><?php echo $present_karnataka;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://karnataka.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col karnataka end -->
      
    <!-- 3rd row end-->  
    
    
     <!--4th row start-->
     <!-- ./col tamilnadu start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Tamilnadu</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg13"><?php echo $reg_tamilnadu;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present13"><?php echo $present_tamilnadu;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://tamilnadu.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col tamilnadu end -->
      
       <!-- ./col andhra Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Andhra</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg14"><?php echo $reg_andhra;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present14"><?php echo $present_andhra;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://andhra.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col andhra end-->
      
       <!-- ./col mizoram start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Mizoram</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg15"><?php echo $reg_mizoram;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present15"><?php echo $present_mizoram;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://mizoram.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col mizoram end -->
      
       <!-- ./col tripura start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Tripura</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg16"><?php echo $reg_tripura;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present16"><?php echo $present_tripura;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://tripura.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col tripura end -->
     <!--4th row end-->
     
      <!--5th row start-->
      <!-- ./col jharkhand start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Jharkhand</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg17"><?php echo $reg_jharkhand;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present17"><?php echo $present_jharkhand;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://jharkhand.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col jharkhand end -->
       <!-- ./col assam Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Assam</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg18"><?php echo $reg_assam;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present18"><?php echo $present_assam;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://assam.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col assam end-->
      
       <!-- ./col manipur start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Manipur</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg19"><?php echo $reg_manipur;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present19"><?php echo $present_manipur;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://manipur.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col manipur end -->
      
       <!-- ./col Meghalaya start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Meghalaya</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg20"><?php echo $reg_meghalaya;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present20"><?php echo $present_meghalaya;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://meghalaya.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col Meghalaya end -->
      
      <!---5th row end-->
      <!--6th row start-->
      <!-- ./col west bengal start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>West Bengal</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg21"><?php echo $reg_wb;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present21"><?php echo $present_wb;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://westbengal.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col West Bengal end -->
      
       <!-- ./col Odisha Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Odisha</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg22"><?php echo $reg_odisha;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present22"><?php echo $present_odisha;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://odisha.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col odisha end-->
       <!-- ./col Jandk start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Jammu & Kashmir</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg23"><?php echo $reg_jk;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present23"><?php echo $present_jk;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://jandk.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col jandk end -->
      
       <!-- ./col himachal start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Himachal</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg24"><?php echo $reg_himachal;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present24"><?php echo $present_himachal;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://himachal.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col himachal end -->
      <!--6th row end-->
      
      <!--7th row start-->
      <!-- ./col up start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Uttar Pradesh</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg25"><?php echo $reg_up;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present25"><?php echo $present_up;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://upgov.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col up end -->
       <!-- ./col rajasthan Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Rajasthan</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg26"><?php echo $reg_rajasthan;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present26"><?php echo $present_rajasthan;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://rajasthan.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col rajasthan end-->
       <!-- ./col arunachal start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>Arunachal Pradesh</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg27"><?php echo $reg_arunachal;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present27"><?php echo $present_arunachal;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://arunachal.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col arunachal end -->
      
       <!-- ./col uk start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Uttrakhand</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg28"><?php echo $reg_uk;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present28"><?php echo $present_uk;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://uk.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col uk end -->
      <!--7th row end-->
      
      <!--8th row start-->
      <!-- ./col sikkim start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Sikkim</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg29"><?php echo $reg_sikkim;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present29"><?php echo $present_sikkim;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://sikkim.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col sikkim end -->
      
       <!-- ./col Delhi Start-->
         <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Delhi</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg30"><?php echo $reg_delhi;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present30"><?php echo $present_delhi;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://delhi.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col delhi end-->
      
       <!-- ./col ut start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-grass">
            <div class="alldashtitle"><h2>UT</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg31"><?php echo $reg_ut;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present31"><?php echo $present_ut;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://ut.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col ut end -->
      
         <!-- ./col chhattisgarh start -->
       <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-wood">
            <div class="alldashtitle"><h2>Chhattisgarh</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg32"><?php echo $reg_chhattisgarh;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present32"><?php echo $present_chhattisgarh;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://chhattisgarh.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col chhattisgarh end -->
      
      <!--8th row end-->
     <!--9th row start-->
     
      <!-- ./col Nagaland start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-light-blue">
            <div class="alldashtitle"><h2>Nagaland</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg33"><?php echo $reg_nagaland;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present33"><?php echo $present_nagaland;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://nagaland.attendance.gov.in" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col nagaland end -->
       <!-- ./col telangana start -->
      <div class="col-lg-3 col-xs-6"> 
        <!-- small box -->
        
        <div class="small-box bg-orange">
            <div class="alldashtitle"><h2>Telangana</h2></div>
            <div class="alldashdetail">
            <div class="inner reg_detal">
            <h3 id="count_reg34"><?php echo $reg_telangana;?> </h3>
            <p class="left_pad_p">Registered </p>
          </div>
            <div class="inner pre_detail">
            <h3 id="count_present34"><?php echo $present_telangana;?> </h3>
            <p>Present Today </p>
          </div>
                </div>    
            
         <!-- <div class="icon"> <i class="fa fa-user"></i> </div>-->
          <a href="http://telangana.attendance.gov.in/" class="small-box-footer" target="_blank"> More info <i class="fa fa-arrow-circle-right"></i> </a> 
            
            </div>
      </div>
      <!-- ./col telangana end -->
    </div>
    </div>
    <!-- /.row --> 
    
    <!-- top row -->
    <div class="row"> 
      <!-- Left col --> 
      <!-- /.Left col --> 
      
	
      <center><h6> Beta Version | Best viewed on Chrome, Firefox, Explorer 11 and above | E-Mail: helpdesk-attendance[@]gov.in | Helpline <img src="<?php echo base_url(); ?>assets/img/phone.jpg" width="30" height="40" alt="phoneimage" > 011-27003511 <br/>
		&copy; <?php echo date('Y'); ?> Attendance.gov.in. All rights reserved.</h6></center>

  </div>
    <!-- /.row --> 
    
    <!-- graph section --> 
    
  </section>
  <!-- /.content --> 
</aside>
<!-- /.right-side -->
</div>
<!-- ./wrapper -->
<?php //$this->load->view('../../__inc/public_foot');?>
 <script src="<?php echo base_url();?>assets/js/jquery.min.js"></script>
	<script  src="<?php echo base_url();?>assets/js/plugins/jqueryKnob/jquery.knob.js" type="text/javascript"></script>
        <script  src="<?php echo base_url();?>assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script  src="<?php echo base_url();?>assets/js/site/app.js" type="text/javascript"></script>
       <!--<script  src="<?php echo base_url();?>assets/js/highcharts.js" type="text/javascript"></script>-->
        <script  src="<?php echo base_url();?>assets/js/countUp.min.js" type="text/javascript"></script>  
        <script  src="<?php echo base_url();?>assets/js/site/alldashboard.js" type="text/javascript"></script>




<!-- add new calendar event modal -->

</body></html>