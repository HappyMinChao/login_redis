<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

/*  Author  : 	Abhishek Ranjan 
	e-Mail	:	abhishek349@gmail.com
	web		:	www.abhishekranjan.com
*/

/* load the MX_Loader class */

require APPPATH."libraries/MX/Loader.php";

class MY_Loader extends MX_Loader {}