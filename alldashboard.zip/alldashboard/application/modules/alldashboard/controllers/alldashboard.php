<?php if (! defined('BASEPATH')) exit('No direct script access allowed');

class Alldashboard extends MY_Controller {

	
	function __construct()
	{
		parent::__construct();
		 $this->load->model('alldashboard_model');
                  $this->load->helper('url');
		
        }
	
        function index(){
           
           
		$result1 = $this->alldashboard_model->count_present_employee(1); //Attendance.gov.
                $result2 = $this->alldashboard_model->count_present_employee(2); //central
                $result3 = $this->alldashboard_model->count_present_employee(3); //haryana
		$result4 = $this->alldashboard_model->count_present_employee(4); //chandigarh
              	$result5 = $this->alldashboard_model->count_present_employee(5); //Maharastra
		$result6 = $this->alldashboard_model->count_present_employee(6); //Bihar
		$result7 = $this->alldashboard_model->count_present_employee(7); //Goa
		$result8 = $this->alldashboard_model->count_present_employee(8); //Punhab
		$result9 = $this->alldashboard_model->count_present_employee(9); //MP
		$result10 = $this->alldashboard_model->count_present_employee(10); //Gujarat
		$result11 = $this->alldashboard_model->count_present_employee(11); //Kerala
		$result12 = $this->alldashboard_model->count_present_employee(12); //Karnataka
		$result13 = $this->alldashboard_model->count_present_employee(13); //Tamilnadu
		$result14 = $this->alldashboard_model->count_present_employee(14); //Andhra
		$result15 = $this->alldashboard_model->count_present_employee(15); //Mizoram
		$result16 = $this->alldashboard_model->count_present_employee(16); //Tripura
		$result17 = $this->alldashboard_model->count_present_employee(17); //Jharkhand
		$result18 = $this->alldashboard_model->count_present_employee(18); //Assam
		$result19 = $this->alldashboard_model->count_present_employee(19); //Manipur
		$result20 = $this->alldashboard_model->count_present_employee(20); //Meghalaya
		$result21 = $this->alldashboard_model->count_present_employee(21); //West Bengal
		$result22 = $this->alldashboard_model->count_present_employee(22); //Odisha
		$result23 = $this->alldashboard_model->count_present_employee(23); //Jammu & Kashmir
		$result24 = $this->alldashboard_model->count_present_employee(24); //Himachal
		$result25 = $this->alldashboard_model->count_present_employee(25); //Uttar Pradesh
		$result26 = $this->alldashboard_model->count_present_employee(26); //Rajasthan
		$result27 = $this->alldashboard_model->count_present_employee(27); //Arunachal Pradesh
		$result28 = $this->alldashboard_model->count_present_employee(28); //Uttrakhand
		$result29 = $this->alldashboard_model->count_present_employee(29); //Sikkim
		$result30 = $this->alldashboard_model->count_present_employee(30); //Delhi
		$result31 = $this->alldashboard_model->count_present_employee(31); //UT
                $result32 = $this->alldashboard_model->count_present_employee(32); //Chhattisgarh
                $result33 = $this->alldashboard_model->count_present_employee(33); //Nagaland
                $result34 = $this->alldashboard_model->count_present_employee(34); //Telangana
                
               
		
//echo '<pre>'; print_r($result);die;
		//Attendance.gov.
		$data['count_present']=$result1->t_in;
                $data['count_reg']=$result1->t_reg;
                
                //central
                $data['present_central']=$result2->t_in;
                $data['reg_central']=$result2->t_reg;
                
                 //Haryana
                $data['present_haryana']=$result3->t_in;
                $data['reg_haryana']=$result3->t_reg;
		
                //chandigarh 
                $data['present_chandigarh']=$result4->t_in;
                $data['reg_chandigarh']=$result4->t_reg;
               
                //maharastra
                $data['present_maharashtra']=$result5->t_in;
                $data['reg_maharashtra']=$result5->t_reg;
                
                //bihar
                $data['present_bihar']=$result6->t_in;
                $data['reg_bihar']=$result6->t_reg;
                
                //goa
                $data['present_goa']=$result7->t_in;
                $data['reg_goa']=$result7->t_reg;
                
                //punjab
                $data['present_punjab']=$result8->t_in;
                $data['reg_punjab']=$result8->t_reg;
                
                //mp
                $data['present_mp']=$result9->t_in;
                $data['reg_mp']=$result9->t_reg;
                
                //gujarat
                $data['present_gujarat']=$result10->t_in;
                $data['reg_gujarat']=$result10->t_reg;
                
                //kerala
                $data['present_kerala']=$result11->t_in;
                $data['reg_kerala']=$result11->t_reg;
                
                //karnataka
                $data['present_karnataka']=$result12->t_in;
                $data['reg_karnataka']=$result12->t_reg;
                
                //tamilnadu
                $data['present_tamilnadu']=$result13->t_in;
                $data['reg_tamilnadu']=$result13->t_reg;
                
                //andhra
                $data['present_andhra']=$result14->t_in;
                $data['reg_andhra']=$result14->t_reg;
                
                 //mizoram
                $data['present_mizoram']=$result15->t_in;
                $data['reg_mizoram']=$result15->t_reg;
                
                 //tripura
                $data['present_tripura']=$result16->t_in;
                $data['reg_tripura']=$result16->t_reg;
                
                 //jharkhand
                $data['present_jharkhand']=$result17->t_in;
                $data['reg_jharkhand']=$result17->t_reg;
                
                 //assam
                $data['present_assam']=$result18->t_in;
                $data['reg_assam']=$result18->t_reg;
                
                 //manipur
                $data['present_manipur']=$result19->t_in;
                $data['reg_manipur']=$result19->t_reg;
                
                 //meghalaya
                $data['present_meghalaya']=$result20->t_in;
                $data['reg_meghalaya']=$result20->t_reg;
                
                 //wb
                $data['present_wb']=$result21->t_in;
                $data['reg_wb']=$result21->t_reg;
                
                //odisha
                $data['present_odisha']=$result22->t_in;
                $data['reg_odisha']=$result22->t_reg;
                
                //j&k
                $data['present_jk']=$result23->t_in;
                $data['reg_jk']=$result23->t_reg;
                
                //himachal
                $data['present_himachal']=$result24->t_in;
                $data['reg_himachal']=$result24->t_reg;
                
                //up
                $data['present_up']=$result25->t_in;
                $data['reg_up']=$result25->t_reg;
                
                //rajasthan
                $data['present_rajasthan']=$result26->t_in;
                $data['reg_rajasthan']=$result26->t_reg;
                
                //Arunachal Pradesh
                $data['present_arunachal']=$result27->t_in;
                $data['reg_arunachal']=$result27->t_reg;
                
                //uk
                $data['present_uk']=$result28->t_in;
                $data['reg_uk']=$result28->t_reg;
                
                //sikkim
                $data['present_sikkim']=$result29->t_in;
                $data['reg_sikkim']=$result29->t_reg;
                
                //delhi
                $data['present_delhi']=$result30->t_in;
                $data['reg_delhi']=$result30->t_reg;
                
                //ut
                $data['present_ut']=$result31->t_in;
                $data['reg_ut']=$result31->t_reg;
                
                //Chhattisgarh
                $data['present_chhattisgarh']=$result32->t_in;
                $data['reg_chhattisgarh']=$result32->t_reg;
                
                //nagaland
                $data['present_nagaland']=$result33->t_in;
                $data['reg_nagaland']=$result33->t_reg;
                
                //Telangana
                $data['present_telangana']=$result34->t_in;
                $data['reg_telangana']=$result34->t_reg;
                 

                //echo $data['attendance_status'];die;
                
                
		$this->load->view('alldashboard_header');
		$this->load->view('alldashboard',$data);
        }
       // *************************************
        public function employeechart(){
          
                error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}
        /********************************************/
                 public function employeechart2(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart2();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}
      
        
          /********************************************/
                 public function employeechart3(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart3();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}  
                 /********************************************/
                 public function employeechart4(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart4();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}
               /********************************************/
                 public function employeechart5(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart5();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}  
              /********************************************/
                 public function employeechart6(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart6();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}   
             /********************************************/
                 public function employeechart7(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart7();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}
                
             /********************************************/
                 public function employeechart8(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart8();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}  
                 /********************************************/
                 public function employeechart9(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart9();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}
             /********************************************/
                 public function employeechart10(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart10();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}    
              /********************************************/
                 public function employeechart11(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart11();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}  
                 /********************************************/
                 public function employeechart12(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart12();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}
                /********************************************/
                 public function employeechart13(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart13();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
                /********************************************/
                 public function employeechart14(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart14();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              /********************************************/
                 public function employeechart15(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart15();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}  
              /********************************************/
                 public function employeechart16(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart16();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		}   
             /********************************************/
                 public function employeechart17(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart17();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                 /********************************************/
                 public function employeechart18(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart18();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
               /********************************************/
                 public function employeechart19(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart19();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
               /********************************************/
                 public function employeechart20(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart20();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                
             /********************************************/
                 public function employeechart21(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart21();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                /********************************************/
                 public function employeechart22(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart22();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
               /********************************************/
                 public function employeechart23(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart23();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
               /********************************************/
                 public function employeechart24(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart24();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
               /********************************************/
                 public function employeechart25(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart25();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                 /********************************************/
                 public function employeechart26(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart26();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                /********************************************/
                 public function employeechart27(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart27();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                /********************************************/
                 public function employeechart28(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart28();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
               /********************************************/
                 public function employeechart29(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart29();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
               /********************************************/
                 public function employeechart30(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart30();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                /********************************************/
                 public function employeechart31(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart31();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
                  /********************************************/
                 public function employeechart32(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart32();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
               /********************************************/
                 public function employeechart33(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart33();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
               /********************************************/
                 public function employeechart34(){
		error_reporting(0);
		header("Cache-Control: no-cache, must-revalidate");
		//echo date('s');
		$result=$this->alldashboard_model->count_employeechart34();
		//print_r($result);
		echo '{"tot_reg":"'.$result->tot_reg.'","t_in":"'.$result->t_in.'"}';
		ob_flush();
		flush();
		die();
		//echo rand(0,100);flush();
		
		} 
              
               
                
                      
                
         public function CheckStatus(){
                
            	$this->load->view('alldashboard_header');
		$this->load->view('checkstatus');
             
         }    
	
  	
}

/* End of file app.php */
/* Location: ./application/modules/app/controllers/app.php */