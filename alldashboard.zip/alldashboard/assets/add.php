<!DOCTYPE HTML>
<html>
    <head>
        <title>MySQL Test Project</title>
    </head>
<body>
 
<h1>MySQL Test Project: Create Employee</h1>
 
<?php
// if the form was submitted
if($_POST){
 
    // connect to database
    include 'libs/db_connect.php';
 
    // sql query
    // INSERT INTO `test_php`.`employeemaster` (`Name`, `Designation`, `Department`) VALUES ('Niraj', 'Programmer', 'VC Division');

    $sql = "INSERT INTO
                employeemaster (Name, Designation, Department)
            VALUES
                (?, ?, ?)";
 
    // if the statement was prepared
    if($stmt = $mysqli->prepare($sql) ){
 
        /*
         * bind the values,
         * "ssss" means 4 string were being binded,
         * aside from s for string, you can also use:
         * i for integer
         * d for decimal
         * b for blob
         */
        $stmt->bind_param(
            "sss",
            $_POST['Name'],
            $_POST['Designation'],
            $_POST['Department']            
        );
 
        // execute the insert query
        if($stmt->execute()){
            echo "Employee added successfully.";
            $stmt->close();
        }else{
            die("Unable to save.");
        }
 
    }else{
        die("Unable to prepare statement.");
    }
 
    // close the database
    $mysqli->close();
}
 
?>
 
<!--we have our html form here where user information will be entered-->
<form action='add.php' method='post' border='0'>
    <table>
        <tr>
            <td>Name</td>
            <td><input type='text' name='Name' /></td>
        </tr>
        <tr>
            <td>Designation</td>
            <td><select id="Designation" name="Designation" onchange="run()">  
            <!--Call run() function-->
            <option value="Programmer">Programmer</option>
            <option value="Sr. Programmer">Sr. Programmer</option>
            <option value="Admin">Admin</option>  
        </select><br></td>
        </tr>
        <tr>
            <td>Department</td>
            <td><select id="Department" name="Department" onchange="run()">  
            <!--Call run() function-->
            <option value="VC Division">VC Division</option>
            <option value="Attendance">Attendance</option>
            <option value="NKN">NKN</option>
        </select><br></td>
        </tr>       
        <tr>
            <td></td>
            <td>
                <input type='submit' value='Save' />
                <a href='index.php'>Back to index</a>
            </td>
        </tr>
    </table>
</form>
 
</body>
</html>