<?php
$db         = mysql_connect('localhost','root','xyz');
$mysql_conn   = mysql_select_db('attendance_app', $db);
if($mysql_conn)
	echo 'done';
else
	echo 'nopes';
if (!mysql_select_db('attendance_app', $db)) { die(mysql_error()); }
$app = mysql_query("SELECT er.emp_id,er.in_time,e.emp_mobile FROM emp_reminders er,attendance_register ar,emp e WHERE er.in_time >  DATE_SUB(NOW(), INTERVAL 15 MINUTE) and sms_sent='N' and date(sms_sent_date)=date(now()) and er.emp_id=ar.emp_id  and e.emp_id=er.emp_id and log_date= date(now())");
if (!$app) {
    die("Query failed: " . mysql_error());
}
echo $app;



while (($tran_data = mysql_fetch_assoc($app)) !== false) {
echo 'while';

  /*   $log_qry="select remarks from log_return_data where transaction_id=$tran_data[transaction_id] order by creation_date desc limit 1";
	$log_res=mysql_query($log_qry);
	$log_data=mysql_fetch_assoc($log_res); */
echo 'updating: '.$tran_data['emp_id'].'<br/>';
$eid=$tran_data['emp_id'];
$up_qry=mysql_query("update emp_reminders set sms_sent='Y',sms_sent_date='2015-04-01' where emp_id='$eid'");

if(!empty($tran_data['emp_mobile']))
{
$msg = 'Dear Sir/Madam,You have not marked your attendance yet.';	
//$subject = 'Your aadhaar updation Info';	
send_sms_msg($tran_data['emp_mobile'] ,$msg); //remove comment later
	
}

}
/* $agency_qry = "SELECT er.emp_id,er.in_time,e.emp_mobile FROM emp_reminders er,attendance_register ar,emp e WHERE er.in_time >  DATE_SUB(NOW(), INTERVAL 15 MINUTE) and sms_sent='N' and date(sms_sent_date)=date(now()) and er.emp_id=ar.emp_id  and e.emp_id=er.emp_id and log_date= date(now())";
$agency_res = mysql_query($agency_qry);
if($agency_res)
{
	echo 'hi';
	while ($agency_data = mysql_fetch_object($agency_res)) {
echo 'while';

  
echo "updating: $tran_data[emp_id]<br/>";
$up_qry=mysql_query("update emp_reminders set sms_sent='Y',sms_sent_date='2015-04-01' where emp_id='$tran_data[emp_id]'");

if(!empty($tran_data[emp_mobile]))
{
$msg = 'Dear Sir/Madam,You have not marked your attendance yet.';	
//$subject = 'Your aadhaar updation Info';	
send_sms_msg($tran_data[emp_mobile] ,$msg); //remove comment later
	
}

}
} */
function send_sms_msg($to = NULL, $msg = NULL)
    {
        if ($to != NULL) {
            //$this->load->helper('url');
            //$this->load->library('Sms_lib');
            
            $msg = $msg;
            
            
            $user   = 'aebas.auth';
            $pass   = 'Mkt*24nK';
            $mobile = $to;
            $sendID = 'NICSMS';
            $text   = urlencode($msg);
/*             
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, "http://smsgw.sms.gov.in/failsafe/HttpLink?username=$user&pin=$pass&message=$text&mnumber=91$mobile&signature=$sendID");
            curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
            $result = curl_exec($ch);
            curl_close($ch); */
           $URL="https://smsgw.sms.gov.in/failsafe/HttpLink";
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,$URL);
			$mystring=$URL;
			$findme="https";
			$pos = strpos($mystring, $findme);
			if($pos >-1)
			{
			curl_setopt($ch, CURLOPT_URL,$URL);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,1);
			curl_setopt($ch, CURLOPT_SSLVERSION, 3);
			curl_setopt($ch, CURLOPT_CAINFO,'/etc/pki/tls/certs/smsgw.sms.gov.in.crt');
			}
			else {
			curl_setopt($ch, CURLOPT_URL,$URL);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,0);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,false);
			}
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS,"username=$user&pin=$pass&message=$text&mnumber=91$mobile&signature=$sendID");
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			 $result =curl_exec($ch);
			 // if (!$result) {
				// echo 'Error, ' . curl_error($ch) . "\n";
				// die;
			// } 
			curl_close($ch);  
            
        } else {
            
        }
    }


?>