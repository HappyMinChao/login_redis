
		//console.log(window.location);
            $(function () {
    $(document).ready(function () {
        Highcharts.setOptions({
            global: {
                useUTC: false
            }
        });

        $('#container').highcharts({
            chart: {
                type: 'spline',
                animation: Highcharts.svg, // don't animate in old IE
                marginRight: 10,
                events: {
                    load: function () {
						 var series = this.series[0];
						
                        setInterval(function () {
							$.ajax({   
							url: "app/livechart", 
							async: false,
							dataType: "html", 
							success: function(y) {
								var x = (new Date()).getTime();
                            series.addPoint([x, parseInt(y)], true, true);
							
								//console.log(a);
							}
						});
                            
                        }, 9000);
                    }
                }
            },
            title: {
                text: ''
            },
            xAxis: {
                type: 'datetime',
                tickPixelInterval: 300
            },
            yAxis: {
                title: {
                    text: 'Value'
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#808080'
                }]
            },
            tooltip: {
                formatter: function () {
                    return '<b>' + this.series.name + '</b><br/>Time : ' +
                        Highcharts.dateFormat('%H:%M:%S', this.x) + '<br/>' +
                        'No.:'+Highcharts.numberFormat(this.y, 0)+'';
                }
            },
            legend: {
                enabled: false
            },
            exporting: {
                enabled: false
            },
            series: [{
                name: 'Presence',
                data: (function () {
                    // generate an array of random data
                    var data = [],
                        time = (new Date()).getTime(),
                        i;

                    for (i = -19; i <= 0; i += 1) {
						data.push({
                            x: time + i * 1000,
                            y: parseInt($('#count_present').html())
                        });
                    }
                    return data;
                }())
            }]
        });

	loadbar();					
	function loadbar(){							
			$.ajax({
							url: "app/employeechart", 
							async: false,
							dataType: "html", 
							success: function(result) {
								//console.log(result);
							var obj = JSON.parse(result);
								
							$('#count_emp').html(parseInt(obj.tot_reg));
   $('#employeechart').highcharts({
        chart: {
            type: 'column'
        },
        title: {
            text: ''
        },
        subtitle: {
            text: ''
        },
        xAxis: {
            categories: [
                'Employees'
            ]
        },
        yAxis: {
            min: 0,
            title: {
                text: 'No. of Employees'
            }
        },
        tooltip: {
            headerFormat: '<span style="font-size:10px">{point.key}</span><table>',
            pointFormat: '<tr><td style="color:{series.color};padding:0">{series.name}: </td>' +
                '<td style="padding:0"><b>{point.y}</b></td></tr>',
            footerFormat: '</table>',
            shared: true,
            useHTML: true
        },
        plotOptions: {
            column: {
                pointPadding: .1,
                borderWidth: 0
            }
        },
		
        series: [	
		
		 {
            name: 'Registered Employee',
            data: [parseInt(obj.tot_reg)],
			color: '#003399'

        },/* {
            name: 'Active Employee',
            data: [parseInt(obj.tot_active)],
			color: '#060'

        }, */{
            name: 'Aadhar Verified ',
            data: [parseInt(obj.tot_qcpass)],
			color: '#3C6'

        }, {
            name: 'Aadhar Rejected',
            data: [parseInt(obj.tot_qcfail)],
			color: '#F00'

        },{
            name: 'QC Pending',
            data: [parseInt(obj.tot_reg)-parseInt(obj.tot_qcpass)-parseInt(obj.tot_qcfail)],
			color: '#FF9933'

        }]
    });
	
	}
	})
	}					

});
});