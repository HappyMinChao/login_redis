<!DOCTYPE HTML>
<html>
    <head>
        <title>MySQL : Create Employee</title>
    </head>
<body>
 
<h1>MySQL : Update Employee Details</h1>
 
<?php
//include database connection
include 'libs/db_connect.php';
 
// if the form was submitted/posted, update the record
if($_POST){
 
    //write query
    $sql = "UPDATE
                employeemaster 
            SET
                Name= ?,
                Designation= ?,
                Department= ?
            WHERE
                EmployeeID = ?";
 
    $stmt = $mysqli->prepare($sql);
 
    // you can bind params this way,
    // ==$row['Department'] ? 'selected' : ''
    // if you want to see the other way, see our add.php
    $stmt->bind_param(
        'sssi',
        $_POST['Name'],
        $_POST['Designation'],
        $_POST['Department'],
        $_POST['EmployeeID']
    );
 
    // execute the update statement
    if($stmt->execute()){
        echo "Employee updated successfully.";
 
        // close the prepared statement
        $stmt->close();
    }else{
        die("Unable to update.");
    }
}
 
/*
 * select the record to be edited,
 * you can also use prepared statement here,
 * but my hosting provider seems it does not support the mysqli get_result() function
 * you can use it like this one http://php.net/manual/fr/mysqli.prepare.php#107568
 
 * so it I'm going to use $mysqli->real_escape_string() this time.ss
 */
 
$sql = "SELECT
             Name, Designation, Department,EmployeeID 
        FROM
            employeemaster 
        WHERE
            EmployeeID = \"" . $mysqli->real_escape_string($_GET['EmployeeID']) . "\"
        LIMIT
            0,1";
 
// execute the sql query
$result = $mysqli->query( $sql );
 
//get the result
$row = $result->fetch_assoc();
 
// php's extract() makes $row['Na'] to $firstname automatically
extract($row);
 
//disconnect from database
$result->free();
$mysqli->close();
?>
 
<!--we have our html form here where new user information will be entered-->
<form action='edit.php?EmployeeID=<?php echo $EmployeeID; ?>' method='post' border='0'>
    <table>
        <tr>
            <td>Name</td>
            <td><input type='text' name='Name' value='<?php echo $Name;  ?>'/></td>
        </tr>
        <tr>
            <td>Designation</td>
            <td><select id="Designation" name="Designation" onchange="run()">  
            <!--Call run() function-->
            <option value="Programmer" <?php if ($Designation== 'Programmer') { echo 'selected="selected"';}?>>Programmer</option>
            <option value="Sr. Programmer" <?php if ($Designation== 'Sr. Programmer') { echo 'selected="selected"';}?>>Sr. Programmer</option>
            <option value="Admin" <?php if ($Designation== 'Admin') { echo 'selected="selected"';}?>>Admin</option>  
        </select><br></td>
        </tr>
        <tr>
            <td>Department</td>
            <td><select id="Department" name="Department" onchange="run()">  
            <!--Call run() function-->
            <option value="VC Division">VC Division</option>
            <option value="Attendance">Attendance</option>
            <option value="NKN">NKN</option>
        </select><br></td>
        </tr>             
        <tr>
            <td></td>
            <td>
                <!-- so that we could identify what record is to be updated -->
                <input type='hidden' name='EmployeeID' value='<?php echo $EmployeeID ?>' />
                <input type='submit' value='Edit' />
                <a href='index.php'>Back to index</a>
            </td>
        </tr>
    </table>
</form>
 
</body>
</html>