<?php
$db           = mysql_connect('10.248.81.190', 'root', 'abhi@1234');
$mysql_conn   = mysql_select_db('attendance_app', $db);


    $res = mysql_query("select e.emp_id,aadhaar,emp_name,designation,emp_mobile,org_name,emp_mail,pic_content from emp e,
						org_master_list ol,
						geo_designation gd,
						emp_doc ed
						where ed.emp_id=e.emp_id and e.desig_id in ('000005','000006','000051','000085') 
						and e.desig_id=gd.desig_id and e.org_id=ol.org_id") or die(mysql_error());
	echo "<table border=1>";
	echo "<tr>";
	echo "<td>Organization</td>";
	echo "<td> Aadhaar no</td>";
	echo "<td>Name</td>";
	echo "<td>Designation</td>";
	echo "<td>Office / Residence Number</td>";
	echo "<td>Mobile No</td>";
	echo "<td>e-mail id</td>";
	echo "<td>Photgraph</td>";
	echo "</tr>";
    if($res)
       { 
	   while($line=mysql_fetch_object($res))
		{
		echo "<tr>";
		echo "<td>".$line->org_name."</td>";
		echo "<td>".$line->aadhaar."</td>";
		echo "<td>".$line->emp_name."</td>";
		echo "<td>".$line->designation."</td>";
		echo "<td> </td>";
		echo "<td>".$line->emp_mobile."</td>";
		echo "<td>".$line->emp_mail."</td>";
		echo "<td>";
			  if($line->pic_content)
			  {
			  echo '<img height="125" width="125" class=" img-thumbnail img-responsive" alt="Responsive image" src="data:image/jpeg;base64,'.$line->pic_content.'"/>';
			  }
			  else
			  {
			  echo '<img height="256" width="200" class=" img-thumbnail img-responsive" alt="Image Not Available" src=""/>';
			}
		
		echo"</td>";
		echo "</tr>";
		} 
        }    
echo "</table>";
?>
