<?php
$db           = mysql_connect('127.0.0.1', 'app_usr1', 'And$baS@321');
$mysql_conn   = mysql_select_db('attendance_data', $db);
$today        = date('Y-m-d');
$dt           = date("Ymd");
$code         = "";
$err_trans_id = "";


    $res = mysql_query("SELECT DISTINCT TABLE_NAME
						FROM INFORMATION_SCHEMA.COLUMNS
						WHERE COLUMN_NAME = 'emp_id'");
    if($res)
       { while($line=mysql_fetch_object($res))
		{
		echo "<br/>";
		echo "ALTER TABLE `$line->TABLE_NAME`
						MODIFY COLUMN emp_id VARCHAR(8) NOT NULL";
		mysql_query("ALTER TABLE `$line->TABLE_NAME` MODIFY COLUMN emp_id VARCHAR(8) NOT NULL ");
		exit;
		}
        }   
?>
