
<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
$config['sms_url'] = 'http://msdgweb.mgov.gov.in/esms/sendsmsrequest';
$config['sms_user'] = 'uidjharsms-uid';
$config['sms_pass'] = 'Supp0rt7$';
$config['sms_sdid'] = 'UIDJHR';
*/

//$config['sms_url'] = 'http://msdgweb.mgov.gov.in/esms/sendsmsrequest';
$config['sms_user'] = 'aebas.auth';
$config['sms_pass'] = 'kt*24nK';
$config['sms_sdid'] = 'NICSMS';



/* End of file sms.php */
/* Location: ./application/config/sms.php */
